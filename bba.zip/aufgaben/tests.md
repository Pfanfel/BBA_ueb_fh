# Tests

Ein ordentlicher Software-Test ruft eine Funktion einer Software ab und vergleicht anschließend das gerade errechnete Ergebnis mit einem erwarteten Ergebnis. Das erwartete Ergebnis muss gesichert korrekt sein. Ein solches Ergebnis wird durch manuelle Berechnung, Vorgabe oder Referenzimplementierung erzeugt. Ein solcher Test kann automatisiert ablaufen.

Wird die Funktion einer Software abgerufen und anschließend manuell überprüft, ist das ein Probelauf und damit *kein* (automatisierbarer) Test. Falls anstelle eines Tests nur eine Probe möglich ist, so ist das berechnete Ergebnis zu archivieren und der manuelle Vergleich zu protokollieren.

In diesem Praktikum gibt es keine vorab gegebenen Tests und auch keinen Server, welcher Tests durchführt. Dies soll verhindern, dass als Lösung [Bananen-Software](https://de.wikipedia.org/wiki/Bananenprinzip) eingereicht wird.

Es werden jedoch die Kommandozeilen, mit welchen die Programmfunktionen abgefragt werden, in der Aufgabenstellung veröffentlicht. Anhand dieser Kommandozeilen sind im Rahmen der Aufgabenbearbeitung selbstständig Tests zu erzeugen. Die Tests sollen der Lösung beigelegt sein. Es ist ausdrücklich erlaubt, Tests über Gruppengrenzen hinweg zu veröffentlichen.

Während der Abnahme wird eine Lösung auch mit anderen als den in der Aufgabe erwähnten Eingaben gestartet, um die Lösung auf allgemeine Verwendbarkeit zu prüfen. Die in Aufgabe 0 geforderte Basisfunktionalität muss unabhängig von der konkreten Aufgabenstellung immer vorhanden sein.

Zum Erzeugen von Referenzergebnissen eignen sich die meisten Werkzeuge zur Bildbearbeitung und -analyse. Beispiele sind ImageMagick, GIMP, IrfanView oder OpenCV.

Als Grundlage für automatisierte Tests kann ein beliebiges Framework verwendet werden. Direkt in bash ließe sich ein Testfall so implementieren:

    convert test.pgm -brightness-contrast 6.25 -compress none test-contrast-expect.pgm
    ./bba --input test.pgm --brightness 0.0625 test-contrast-calculated.pgm
    diff --brief test-contrast-* && echo "Test OK" || echo "Abweichung gefunden"

Selbstverständlich sind die Referenzergebnisse nicht mit dem zu testenden Programm zu erzeugen. Ein "Test" wie dieser ist daher **nicht brauchbar**:

    $( ./bba --input test.pgm --identity --output - ) == $( ./bba --input test.pgm --identity --output - )
