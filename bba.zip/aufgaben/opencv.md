Hier werden einige Grundlagen zur Arbeit mit OpenCV beschrieben.

In den ersten drei Aufgaben dieses Praktikums verwenden wir die Datenstrukturen und Funktionen von OpenCV vorrangig zum Laden und Speichern von Bildern.

## Installation

 *  Ubuntu Linux: `apt install libopencv-dev`
 *  alle anderen: laden OpenCV 3.2.0 [hier](https://opencv.org/releases.html) herunter und folgen ansonsten den  offiziellen [Hinweisen](https://docs.opencv.org/3.2.0/df/d65/tutorial_table_of_content_introduction.html)

Es ist leichter, passende vorkompilierte Pakete zu verwenden, als OpenCV selbst zu kompilieren.  
Wesentlich leichter.  
Im Ernst. Du baust dir OpenCV nur dann selbst, wenn dadurch dein Leben als Ganzes irgendwie besser wird.

## Verwendung

Ein guter Ausgangspunkt für den Einstieg in die Arbeit mit OpenCV ist das [Beispiel](http://docs.opencv.org/3.2.0/db/deb/tutorial_display_image.html) zum Laden und Anzeigen von Bildern aus der Dokumentation.

## Namensraum

Die Dokumentation geht implizit davon aus, dass im Namensraum `cv` gearbeitet wird. Zum Verwenden der Funktionen und Datenstrukturen muss der Namensraum explizit mit dem Voranstellen von `cv::` ausgewählt werden.

## Datenstruktur für Bilddaten `cv::Mat`

In OpenCV ist `cv::Mat` die Standard-Datenstruktur, welche Bilddaten hält.

    cv::Mat A = cv::Mat(480, 640, CV_8UC1, cv::Scalar::all(0));
    cv::Mat B = cv::imread("example.png", CV_LOAD_IMAGE_GRAYSCALE);
    
Dieser Code erzeugt ein schwarzes Bild A. Als Format wird `CV_8UC1` vorgegeben: 8 Bit pro Pixel, ohne Vorzeichen, davon ein Kanal; also ein Graustufenbild.  
Ein weiteres Bild B wird aus einer Datei geladen. Unabhängig vom eigentlichen Inhalt der Datei wird das Bild als Graustufenbild geladen.

OpenCV ist auf Geschwindigkeit ausgelegt und kopiert Daten normalerweise **nicht** (*dies ist eine Abweichung vom üblichen Zuweisungsverhalten der Container der C++ Standardbibliothek*). Das Kopieren von Bildinhalten muss bei `cv::Mat` explizit angefordert werden.

    cv::Mat B = A; // Kopiert nicht die Daten (nur den Header)
    cv::Mat C = B.clone(); // Kopiert auch Daten

## Zugriff auf Farbkanäle

Globale Transformationen werden klassisch auf Bilder mit einem Kanal (Graustufen) angewendet. Mit Hilfe von `cv::split` und `cv::merge` können die Farbkanäle eines Farbbildes auf drei separate Bilder verteilt und wieder zusammengefügt werden.

    std::vector<cv::Mat> channels;
    cv::split(A, channels);
    // ... Dinge geschehen hier ...
    cv::merge(channels, A);

## Zugriff auf Pixel

Die folgenden Beispiele verdoppeln die Intensität jedes Pixels. Hierfür gibt es die Methode `cv::Mat::at<T>`. Diese Methode hat zwei Besonderheiten: 

 1.  Sie verwendet ein Template. 
 2.  Sie gibt eine Referenz zurück.

Aufgrund der generischen Formulierung mit Template muss explizit angegeben werden, wie auf das Pixel zugegriffen werden soll.

Handelt es sich um ein Graustufenbild mit 8 Bit ohne Vorzeichen pro Pixel. Daher muss das Pixel als vorzeichenloses Byte, also `unsigned char` zugegriffen werden.  
Weil `cv::Mat::at<T>` eine Referenz zurückgibt, kann auf diese auch geschrieben werden.

    for ( int y = 0; y < image.rows; y++ ) {
      for ( int x = 0; x < image.cols; x++ ) {
          image.at<uchar>(y,x) =
            cv::saturate_cast<uchar>( 2 * image.at<uchar>(y,x) );
      }
    }

Handelt es sich hingegen um ein BGR Farbbild, mit 8 Bit ohne Vorzeichen pro Pixel auf drei Kanälen, so wird ein farbiger Pixel als Vektor von drei Bytes repräsentiert.

    for (int y = 0; y < image.rows; y++) {
      for (int x = 0; x < image.cols; x++) {
        for (int c = 0; c < 3; c﻿++) {
          image.at<Vec3b>(y,x)[c] =
            cv::saturate_cast<uchar>( 2 * image.at<Vec3b>(y,x)[c] );
        }
      }
    }

`cv::saturate_cast<T>` ist eine praktische Hilfsfunktion, welche den Wert eines Pixels automatisch auf die Randwerte des angegebenen Datentyps beschränkt.

Dieses Beispiel zeigt, dass `cv::Mat` sich nicht "merkt", von welchem Datentyp die einzelnen Pixel sind, welche das Bild darstellen. Daher muss man den Datentyp bei `at<T>(…)` explizit angeben. Wem das zu unbequem ist, der kann `cv::Mat_<T>` verwenden, um gleich bei der Deklaration den Datentyp anzugeben. Damit wird Flexibilität eingebüßt, die im Rahmen des Praktikums allerdings nicht überall notwendig ist.

*Randnotiz für spätere Projekte: In OpenCV arbeitet man normalerweise nicht auf einzelnen Pixeln. Die meisten Operationen sind sehr performant in OpenCV implementiert.*

## Farbräume, Anzeige und Dateien

OpenCV behandelt Bilder intern bevorzugt im Format mit 8 Bit pro Pixel, ohne Vorzeichen, davon drei Kanäle, Sortierung BGR. Es ist davon auszugehen, dass nur dieses Format sich unfallfrei anzeigen und speichern lässt.

## C-Varianten

OpenCV definiert die meisten Funktionen sowohl in einer C- als auch in einer C﻿++-Variante. Die C-Funktionen sollen nicht verwendet werden. In der Dokumentation wird explizit zwischen den Varianten unterschieden.  
Beispiel: Die C-Variante von [`cv::cvtColor`](http://docs.opencv.org/3.2.0/d7/d1b/group__imgproc__misc.html#ga397ae87e1288a81d2363b61574eb8cab) erwartet als Parameter u.a. einen *Zeiger* auf eine vorher manuell allozierte Datenstruktur vom Typ `CvArr`. Die C﻿++Variante `cv::cvtColor` erwartet hingegen u.a. einen Parameter vom Typ `cv::InputArray`, für den konkret ein `cv::Mat` verwendet werden kann.
