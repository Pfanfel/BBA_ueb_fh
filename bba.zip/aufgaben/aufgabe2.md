In dieser Aufgabe geht es um morphologische Filter, lokale Filter und die dafür notwendige Randbehandlung.

Beim Bearbeiten dieser Aufgabe ist zu beachten, dass die Rahmenbedingungen zu Richtlinien und Bewertung für alle Aufgaben gelten.

<nolink>
#### Aufgabenstellung

Basisteil:

 *  Randbehandlung: null, Konstante, replicate
 *  Erzeugen: values ← TODO: umbenennen zu "new"?
 *  lokaler Filter (Faltung): fold

TODO: fold erzeugt float oder s16? explizites rückkonvertieren durch clamp/normalize?

Bewertungsteil:

 *  Randbehandlung: reflect11, reflect101 (2 Punkte)
 *  Rangordnungsfilter: erode, dilate, median (2 Punkte)
 *  lokale Filter: box, sobel, gauss, laplace (3 Punkte)
 *  Bildanalyse: Wald/Treppe-Unterscheider (2 Punkte)

##### Details

 *  In dieser Aufgabe werden nur Graustufenbilder gelesen und geschrieben.

 *  Die Filter sollen manuell implementiert werden. Das Aufrufen der jeweiligen Impelementierung aus OpenCV ist nicht erlaubt.

 *  Bildeingabe 

     *  Filter `values`  
        Erstellt aus den vom Benutzer übergebenen Parametern ein Bild. Der erste Parameter gibt die Breite an, der zweite Parameter die Höhe.

            bba --input test.pgm --values 3 2 .1 .2 .3 4 5 6 --output -

        Der letzte Aufruf führt intern zu diesem Bild:

            0.1  0.2  0.3
              4    5    6
            
        Interessant in Kombination mit dem Filter `fold`.

 *  Randbehandlung `--edge <Option>`  
    Wenn lokale Filter am Rand des Bildes arbeiten, möchten sie Intensitäten von Pixeln lesen, welche außerhalb des Quellbildes liegen. Daher ist eine Randbehandlung notwendig. Diese Behandlung ist pixelweise algorithmisch zu lösen, sodass – theoretisch – auch dann passende Werte geliefert werden, wenn die Indizes gegen unendlich wachsen. `copyMakeBorder` darf nicht verwendet werden (das Implementieren ist die Aufgabe). Es ist nicht erlaubt, ein temporäres Bild zu erzeugen, welches größer als notwendig ist. Diese Methoden zur Randbehandlung sollen implementiert werden:

     *  `--edge null`  
        Rand wird als schwarz behandelt. Dies ist die Standardeinstellung für das Programm dieses Praktikums.

     *  `--edge <Wert>`  
        Rand wird als konstante Intensität des angegebenen Werts behandelt. 0.0 sei schwarz, 1.0 die volle Intensität (weiß).  
        *Für Hörer der Veranstaltung "Computergraphik": Dies ist wie `GL_CLAMP_TO_BORDER`.*

     *  `--edge replicate`  
        Rand hat die Intensität des nächstgelegenen gültigen Pixels.  
        *Für Hörer der Veranstaltung "Computergraphik": Dies ist wie `GL_CLAMP_TO_EDGE`.*

     *  `--edge reflect11`  
        Das Bild wird über die Kante hinweg gespiegelt.  
        *Für Hörer der Veranstaltung "Computergraphik": Dies ist wie `GL_MIRRORED_REPEAT`.*

     *  `--edge reflect101`  
        Das Bild wird über den am Rand liegenden Pixel hinweg gespiegelt. Der Sonderfall des 1-Pixel-Bildes darf ignoriert werden.

 *  Lineare lokale Filter

     *  Filter `fold`  
        Interpretiert das oberste Bild auf dem Stapel als Matrix. Wendet die Matrix als Kern eines lokalen Filters auf das zweite Bild an. Beide Bilder werden vom Stapel entfernt, das Ergebnisbild auf den Stapel gelegt. `fold` geht davon aus, dass die Matrix quadratisch ist und eine ungerade Anzahl an Pixeln auf jeder Seite hat, sodass die Mitte eindeutig bestimmt ist.
     
        Beispielaufruf:

            bba --input test.pgm --values 1 1 1 --fold --output - # Identität
            bba --input test.pgm --values 3 3 0 0 0 0 1 0 0 0 0 --fold --output - # Identität
            bba --input test.pgm --values 3 3 1 1 1 1 1 1 1 1 1 --factor .111111 --fold --output - # Mittelwert
            bba --input test.pgm --values 3 3 1 1 1 1 1 1 1 1 1 --factor .111111 --edge replicate --fold --output - # Mittelwert (Rand wird nicht dunkel)
            bba --input test.pgm --values 5 5  1 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0 0 --fold --output - # diagonales Verschieben
            bba --input test.pgm --values 5 5  1 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0 0 --edge 1 --fold --output - # diagonales Verschieben (Ecke wird weiß)

     *  Filter `box`  
        Der Box-Filter bestimmt den Mittelwert.

        Beispielaufruf:

            bba --input test.pgm --box --fold --output -

     *  Filter `gaussian`  
        Erzeugt ein Bild für den Gauß-Filter und legt ihn auf den Stapel. Der Gauß-Filter ist ein Weichzeichner.  

        TODO: Gauß nach Vorschrift berechnen lassen: Größe explizit überdimensionieren, damit Marr-Hildreth gebaut werden kann

        Dieser Kern soll verwendet werden:

            1/16 2/16 1/16
            2/16 4/16 2/16
            1/16 2/16 1/16

        Beispielaufruf:

            bba --input test.pgm --gaussian --fold --output -

     *  Filter `sobel-x` und `sobel-y`  
        Erzeugt ein Bild für den jeweiligen Sobel-Filter und legt ihn auf den Stapel. Der Sobel Filter ist ein gerichteter Kantendetektor.

        Beispielaufruf:

            bba --input test.pgm --sobel-x --fold --clamp --output - # hebt horizontale Kontrastübergänge hervor
            bba --input test.pgm --sobel-y --fold --clamp --output - # hebt vertikale Kontrastübergänge hervor
            
     *  Filter `laplace`  
        Erzeugt ein Bild und legt es auf den Stapel. Der Laplace Filter ist ein bidirektionaler Kantendetektor.

            0  1  0
            1 -4  1
            0  1  0

        Beispielaufruf:

            bba --input test.pgm --laplace --fold --clamp --output -

 *  Rangordnungsfilter  
    Diese Filter benötigen keine Randbehandlung: Wo keine Pixel zu lesen sind, wird keiner ausgewählt.

     *  Filter `median`  
        Der Median Filter wählt den mittleren Wert aus. Hat das Bild eine gerade Anzahl an Bildpunkten, wird der kleinere Wert (Untermedian) ausgewählt (es sollen keine Intensitätswerte entstehen können, die nicht schon vorher im Bild waren).
        
        Beispielaufruf:

            bba --input test.pgm --median --output -

     *  Filter `erode`  
        Die Erosion wählt das einfache Minimum aus den neun (3 x 3 Pixel Quadrat) umliegenden Werten aus. Es sollen keine Additionen stattfinden.

        Beispielaufruf:

            bba --input test.pgm --erode --output -

     *  Filter `dilate`  
        Die Dilatation wählt das einfache Maximum aus den neun (3 x 3 Pixel Quadrat) umliegenden Werten aus. Es sollen keine Additionen stattfinden.

        Beispielaufruf:

            bba --input test.pgm --dilate --output -

 *  Filterketten  
    Es soll immer noch möglich sein, Filter beliebig zu verketten.

    Beispielaufruf:

        bba --input test.pgm --gaussian --laplace --fold --fold --clamp --output -

    Dies ist eine Variante des "Mexican Hat" bzw. "Marr-Hildreth" Filters.

 *  Bildanalyse  
    Als Hobbyphotograph und Künstler mache ich grundsätzlich nur Graustufenbilder von exakt zwei Motiven:

     *  Wälder mit **vertikal** stehenden Bäumen.
     *  Treppen mit **horizontal** verlaufenden Stufen.

    <img src="http://intern.fh-wedel.de/~hoe/typolike/wald1.png" title="Grayscale segment of 'Forest' by Sebastian Wojnicki on flickr" style="height:4em;">
    <img src="http://intern.fh-wedel.de/~hoe/typolike/wald2.png" title="Grayscale segment of 'Dead Forest' by Simon Claessen on flickr" style="height:4em;">
    <img src="http://intern.fh-wedel.de/~hoe/typolike/wald3.png" title="Grayscale segment of 'Forest' by Stiller Beobachter on flickr" style="height:4em;">
    <img src="http://intern.fh-wedel.de/~hoe/typolike/treppe1.png" title="Grayscale segment of 'Stairs' by David Calvet on flickr" style="height:4em;">
    <img src="http://intern.fh-wedel.de/~hoe/typolike/treppe2.png" title="Grayscale segment of 'Stairs to Street' by Matthew Robinson on flickr" style="height:4em;">
    <img src="http://intern.fh-wedel.de/~hoe/typolike/treppe3.png" title="Grayscale segment of 'Stairs' by R. Crap Mariner on flickr" style="height:4em;">
     
    Nachdem ich neulich meinen USB-Stick zu heftig geschüttelt habe, sind alle Bilder durcheinandergeraten. Schreibe einen Filter `discriminator`, welcher die Bilder unterscheidet. Zum Erstellen des Filters sind die in dieser und den vorigen Aufgaben erstellten Funktionen ausreichend. Weitere OpenCV Funktionen sollen daher nicht verwendet werden. Die Antwort soll als Zeichenkette `wald` oder `treppe` auf der Standardausgabe erfolgen, sodass ein Zeichenkettenvergleich möglich ist. Debugausgaben sollten daher auf der Standardfehlerausgabe gemacht werden.

    Beispielaufrufe:

        $ bba --input wald1.pgm --discriminator
        wald
        $ bba --input treppe1.pgm --discriminator
        treppe

##### Hinweise

 *  Eine implizite Normierung der Filterantworten soll nicht stattfinden. Der Kern des Gauß-Filters ist bereits normiert angegeben. Der Benutzer soll die Normierung explizit mittels `factor` anfordern können.

 *  Soweit nicht anders angegeben, verwenden alle lokalen Filter eine quadratische Matrix der Höhe und Breite 3.

 *  OpenCV sowie praktisch alle Sammlungen der C++ Standardbibliothek nummerieren Indizes mit natürlichen Zahlen ab 0. Die in der Vorlesung gezeigte mathematische Definition der Filtermaske verwendet positive und negative Indizes um `(0,0)` als Zentrum. Diese Verschiebung der Indizes muss nicht emuliert werden.

 *  Zum Testen ist es oftmals nützlich, mit kleinen Bildern zu arbeiten, auf denen nur ein Pixel eine hervorgehobene Intensität besitzt.
</nolink>

#### Gruppenzuordnung bei Abnahme:

Rotation der Verteilung von voriger Abnahme.  

Zeitslots:

1. 11:00
1. 11:30
1. 12:00
1. 12:30
1. 13:00

**Hermann "hoe" Höhne** – 🐧 (⊞)
