#include <functional>
#include <algorithm>
#include <opencv2/opencv.hpp>

namespace bba {
typedef std::vector<cv::Mat> imagestack;
class ForeachPixel {
// Hilfsklasse zum Iterieren über alle Pixel eines Bildes
public:
    virtual void calculate_pixel(cv::Mat &, int, int) = 0;
    virtual void for_each_pixel(cv::Mat & img) {
        for (int y = 0; y < img.rows ; y++) {
            for (int x = 0; x < img.cols ; x++) {
                calculate_pixel(img, y, x);
            }
        }
    }
};
class Filter {
// Basisklasse für alle Filter
public:
    virtual bool apply(imagestack & stack) = 0;
    virtual ~Filter() {}; // https://stackoverflow.com/questions/461203/
};
template<typename T>
class Median : public Filter {
// ein Median-Filter
private:
    int size;
    class MedianForeach : public ForeachPixel {
    private:
        // diese stünden bei einem Lambda-Ausdruck in der Capture Group
        const int border;
        const cv::Mat & input;
        const cv::Rect input_rect;
    public:
        MedianForeach(const cv::Mat & input, const int size) : 
            border((size-1)/2),
            input(input), 
            input_rect(cv::Point2i(0,0), input.size())
        {}
        virtual void calculate_pixel(cv::Mat & m, int y, int x) {
            // dies ist der eigentliche Funktionsrumpf
            std::vector<T> v;
            for (int ys = y-border ; ys <= y+border ; ys++) {
                for (int xs = x-border ; xs <= x+border ; xs++) {
                    cv::Point2i pt(xs,ys);
                    if (input_rect.contains(pt)) {
                        v.push_back(input.at<T>(pt));
                    }
                }
            }
            std::nth_element(v.begin(), v.begin() + (v.size()-1)/2, v.end());
            m.at<T>(y, x) = v[(v.size()-1)/2];
        }
    };
public:
    Median(const int & size) : size(size) {}
    virtual bool apply(imagestack & stack) {
        // Wrapper für Aufruf mit Stack
        cv::Mat img = stack.back();
        stack.pop_back();
        // jetzt neu: Graustufen-Filter arbeitet auf Farbbildern (jeder Kanal einzeln)
        std::vector<cv::Mat> channels;
        cv::split(img, channels);
        for (cv::Mat & c : channels) {
            c = execute(c, size);
        }
        cv::merge(channels, img);
        stack.push_back(img);
        return true;
    }
    static cv::Mat execute(const cv::Mat & img, const int size) {
        // statische Methode für direkte Zugreifbarkeit zur Wiederverwendbarkeit
        cv::Mat result(img.size(), img.type());
        MedianForeach(img, size).for_each_pixel(result);
        return result;
    }
};
class Print : public Filter {
public:
    virtual bool apply(imagestack & stack) {
        execute(stack.back());
        return true;
    }
    static void execute(const cv::Mat & img) {
        cv::Mat gray(img);
        if (img.channels() > 1) {
            cv::cvtColor(img, gray, cv::COLOR_BGR2GRAY);
        }
        std::cerr << gray << std::endl;
    }
};
class Input : public Filter {
private:
    const cv::Mat img;
public:
    Input(std::string filename) : img(cv::imread(filename, cv::IMREAD_UNCHANGED)) {}
    virtual bool apply(imagestack & stack) {
        stack.push_back(img);
        return true;
    }
};
class Output : public Filter {
private:
    const std::string filename;
public:
    Output(std::string filename) : filename(filename) {}
    virtual bool apply(imagestack & stack) {
        const cv::Mat img = stack.back();
        stack.pop_back();
        cv::imwrite(filename, img);
        return false;
    }
};
class VideoIn : public Filter {
private:
    cv::VideoCapture vc;
    double & framerate;
    int frameno;
public:
    VideoIn(std::string filename, double & framerate) : vc(filename), framerate(framerate), frameno(0) {
        framerate = vc.get(cv::CAP_PROP_FPS);
    }
    virtual bool apply(imagestack & stack) {
        std::cerr << "Lese Frame " << ++frameno << std::endl;
        cv::Mat img;
        vc >> img;
        stack.push_back(img);
        return !img.empty();
    }
};
class VideoOut : public Filter {
private:
    cv::VideoWriter vw;
    const std::string filename;
    double & framerate;
public:
    VideoOut(std::string filename, double & framerate) : filename(filename), framerate(framerate) {}
    virtual bool apply(imagestack & stack) {
        const cv::Mat img = stack.back();
        stack.pop_back();
        if (!vw.isOpened()) {
            auto fourcc = cv::VideoWriter::fourcc('M','J','P','G');
            std::cerr << "Öffne Videodatei " << filename << " zur Ausgabe mit " << framerate << " fps…" << std::endl;
            vw.open(filename, fourcc, framerate, img.size());
        }
        std::cerr << "Schreibe dieses Bild in Video " << filename << ": " << std::endl;
        Print::execute(img); // Demonstration Wiedervewendbarkeit: Filter können auch ohne Stack direkt eingesetzt werden
        vw << img;
        return true;
    }
};
} // namespace bba

typedef std::vector<std::unique_ptr<bba::Filter>> Operations;

int main(int argc, char** argv) {
    // globale Zustände
    double framerate = 0.0f;
    // enum randbehandlung
    // float rand_wert
    // enum interpolation
    // etc.

    // Parsen und Zuordnen
    Operations operations;
    std::vector<std::string> arguments(argv + 1, argv + argc);
    std::vector<std::string>::const_iterator it = arguments.cbegin(), end = arguments.cend();
    std::function<std::string(void)> next_arg = [&it, &end] {
        if (it == end) {
            throw std::runtime_error("Nicht genügend Argumente.");
        }
        return *it++;
    };
    while (it != end) {
        const std::string & action = next_arg();
        if (action == "--input") {
            operations.push_back(std::make_unique<bba::Input>(next_arg()));
        } else if (action == "--output") {
            operations.push_back(std::make_unique<bba::Output>(next_arg()));
        } else if (action == "--videoin") {
            operations.push_back(std::make_unique<bba::VideoIn>(next_arg(), framerate));
        } else if (action == "--videoout") {
            operations.push_back(std::make_unique<bba::VideoOut>(next_arg(), framerate));
        } else if (action == "--print") {
            operations.push_back(std::make_unique<bba::Print>());
        } else if (action == "--median") {
            operations.push_back(std::make_unique<bba::Median<uchar>>(std::stoi(next_arg())));
        } else {
            throw std::runtime_error(std::string("Unbekannter Parameter ")+action);
        }
    }

    // Ausführen
    for (bool ok = true; ok;) {
        bba::imagestack stack;
        for (const auto & so : operations) {
            ok = so->apply(stack);
            if (!ok) {
                break;
            }
        }
    }
    return 0;
}
