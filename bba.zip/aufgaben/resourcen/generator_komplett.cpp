#include <functional>
#include <opencv2/opencv.hpp>
namespace argparse {
enum Action {
    ACTION_NONE,
    ACTION_INPUT,
    ACTION_OUTPUT,
    ACTION_VIDEOIN,
    ACTION_VIDEOOUT,
    ACTION_PRINT,
};
struct Operation {
    Action action;
    std::string filename;
    std::vector<float> filter_parameter;
};
typedef std::vector<Operation> Operations;
Operations parse_arguments(int argc, char *argv[]) {
    Operations operations;
    std::vector<std::string> arguments(argv + 1, argv + argc);
    std::vector<std::string>::const_iterator it = arguments.cbegin(), end = arguments.cend();
    std::function<std::string(void)> next_arg = [&it, &end] {
        if (it == end) {
            throw std::runtime_error("Nicht genügend Argumente.");
        }
        return *it++;
    };
    while (it != end) {
        const std::string & action = next_arg();
        if (action == "--input") {
            Operation op;
            op.action = ACTION_INPUT;
            op.filename = next_arg();
            operations.push_back(op);
        } else if (action == "--output") {
            Operation op;
            op.action = ACTION_OUTPUT;
            op.filename = next_arg();
            operations.push_back(op);
        } else if (action == "--videoin") {
            Operation op;
            op.action = ACTION_VIDEOIN;
            op.filename = next_arg();
            operations.push_back(op);
        } else if (action == "--videoout") {
            Operation op;
            op.action = ACTION_VIDEOOUT;
            op.filename = next_arg();
            operations.push_back(op);
        } else if (action == "--print") {
            Operation op;
            op.action = ACTION_PRINT;
            operations.push_back(op);
        } else {
            throw std::runtime_error(std::string("Unbekannter Parameter ")+action);
        }
    }
    return operations;
}
} // namespace argparse 

namespace bba {
typedef std::vector<cv::Mat> imagestack;
typedef std::function<bool(imagestack &)> stack_operation;
} // namespace bba 

std::vector<bba::stack_operation> bind_operations(const argparse::Operations & operations) {
    std::vector<bba::stack_operation> stack_operations;
    for (const argparse::Operation & operation : operations) {
        switch (operation.action) {
            case argparse::ACTION_INPUT: {
                const std::string & filename = operation.filename;
                const cv::Mat img = cv::imread(filename);
                stack_operations.push_back(
                    [img](bba::imagestack & stack) {
                        stack.push_back(img);
                        return true;
                    }
                );
            } break;
            case argparse::ACTION_VIDEOIN: {
                const std::string & filename = operation.filename;
                cv::VideoCapture vc(filename);
                stack_operations.push_back(
                    [vc](bba::imagestack & stack) mutable {
                        cv::Mat img;
                        vc >> img;
                        stack.push_back(img);
                        return !img.empty();
                    }
                );
            } break;
            case argparse::ACTION_OUTPUT: {
                const std::string & filename = operation.filename;
                stack_operations.push_back(
                    [filename](bba::imagestack & stack) {
                        const cv::Mat img = stack.back();
                        stack.pop_back();
                        cv::imwrite(filename, img);
                        return false;
                    }
                );
            } break;
            case argparse::ACTION_VIDEOOUT: {
                const std::string & filename = operation.filename;
                cv::VideoWriter vw;
                stack_operations.push_back(
                    [vw, filename](bba::imagestack & stack) mutable {
                        const cv::Mat img = stack.back();
                        stack.pop_back();
                        if (!vw.isOpened()) {
                          auto fourcc = cv::VideoWriter::fourcc('M','J','P','G');
                          vw.open(filename, fourcc, 25, img.size());
                        }
                        vw << img;
                        return true;
                    }
                );
            } break;
            case argparse::ACTION_PRINT: {
                stack_operations.push_back(
                    [](bba::imagestack & stack) {
                        cv::Mat gray;
                        cv::cvtColor(stack.back(), gray, cv::COLOR_BGR2GRAY);
                        std::cerr << gray << std::endl;
                        return true;
                    }
                );
            } break;
            default: {
            } break;
        }
    }
    return stack_operations;
}

int main(int argc, char** argv) {
    argparse::Operations operations = argparse::parse_arguments(argc, argv);
    std::vector<bba::stack_operation> stack_operations = bind_operations(operations);
    for (bool ok = true; ok;) {
        bba::imagestack stack;
        for (const bba::stack_operation & so : stack_operations) {
            ok = so(stack);
            if (!ok) {
                break;
            }
        }
    }
    return 0;
}
