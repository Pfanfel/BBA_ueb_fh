Im Rahmen dieses Praktikums wird mit C++17 gearbeitet. Hier sind einige Hinweise und Grundlagen zusammengefasst.

C++17 bietet gegenüber älteren Standards wie C++98 eine Reihe von Neuerungen. Einige der interessanten neuen Funktionen werden hier beschrieben. Die Beschreibungen sind als **Hinweise** zu verstehen, die hilfreich sein sollen. Es sind keine Anweisungen; es ist **nicht notwendig**, sie zu befolgen.

## Entwicklungsumgebung

Es gibt eine Vielzahl von Entwicklungsumgebungen für C++. Beliebt sind unter anderem

 *  QtCreator
 *  Eclipse (im C/C++ Modus)
 *  Visual Studio Code
 *  CLion
 
Natürlich eignet sich jeder beliebige Texteditor wie geany, emacs, vi, nano oder auch Notepad++ zum Bearbeiten der Quellen.

Unter Windows kann auch Visual Studio verwendet werden. Im Rahmen dieses Praktikums bietet das Verwenden von cygwin keine Vorteile.

## Hilfe

 *  [cppreference](http://en.cppreference.com/w/)  
    Dies ist die genaueste und umfangreichste Online-Dokumentation zu C++. Ratschläge auf anderen Seiten sind oftmals mit Vorsicht zu genießen.  
    Auf cppreference ist eine gute Übersicht über die Standard-Template-Library zu finden. Hier sind die gängigsten Sammlungen implementiert: Listen, Paare, Zuordnungen, Mengen,...
 
 *  [stackoverflow](http://stackoverflow.com/)  
    Auf stackoverflow sind mit großer Wahrscheinlichkeit alle übrigen Fragen beantwortet.  
    Hierzu gibt es eine Faustregel: *Wenn deine Frage auf stackoverflow nicht gestellt wurde, ist es nicht die richtige Frage.*

## Besonderheiten von C++

### Namensräume

In C++ gibt es Namensräume. Diese sind vergleichbar mit den Namen von Java packages. Man erreicht damit die semantische Trennung verschiedener Module und vermeidet so Mehrdeutigkeiten. Das Verwenden von `using`-Direktiven ist daher zu meiden.

### Ausgabe

In C++ wird der Datenstrom der Standardausgabe als Objekt repräsentiert. `cout` ist im Header `iostream` für den Namensraum `std` definiert. Der für `std::cout` definierte Operator `<<` wird verwendet, um auf die Standardausgabe zu schreiben.

#### Beispiel

    #include <iostream> // für std::cout

    /**
     * Einstiegspunkt zur Demonstration von bereichsbasierten Schleifen.
     */
    int main(int argc, char *argv[]) {
        // gibt die Zeichenkette Hallo Welt und ein newline aus
        std::cout << "Hallo Welt" << std::endl;
        int eins = 1;
        // Konvertiert "eins" implizit als Dezimalzahl in einen String und gibt diesen aus
        std::cout << eins << std::endl;
    }

### Zeiger sind vermeidbar

C++ ist abwärtskompatibel zu C. Ein wichtiger Unterschied ist die in C++ bequemere Speicherverwaltung. Es ist in C++ möglich Zeiger zu verwenden. Ein Beispiel bildet der Zugriff auf die Kommandozeilenparameter, welche aus Kompatibilitätsgründen als C-Strings zur Verfügung stehen. Allerdings ist es mit wenig Aufwand möglich, das C-array von C-Strings in einen C++ `std::vektor` von `std::strings` zu verwandeln. Es ist zur Lösung der Aufgaben ansonsten nicht notwendig, Zeiger zu verwenden.

#### Beispiel

    /**
     * @file vectorvsarraydemo.cpp
     * @brief Beispielprogramm zur Demonstration von Vektoren im Vergleich zu Arrays.
     */

    #include <iostream> // für std::cout
    #include <vector> // für std::vector

    /**
     * Dieser Einstiegspunkt baut einen
     * praktischen C++ "Vektor von Strings" aus einem
     * hakeligen C "Zeiger auf Zeiger von char".
     */
    int main(int argc, char *argv[]) {

        std::vector<std::string> arguments(argv + 1, argv + argc);
        for (std::string s : arguments) {
            std::cout << s << std::endl;
        }
    }

### Rückwärtskompatibilität

C++ ist abwärtskompatibel zu C. Es ist möglich, im Rahmen dieses Praktikums aber ausdrücklich **nicht** erwünscht, Funktionen aus C zu verwenden. 

 *  Anstelle von `strcmp` zum Vergleichen von C-Strings, ist der Vergleichsoperator `==` von `std::string` Objekten zu verwenden. 
 *  Anstelle von `sscanf` zum Extrahieren von Zahlen aus C-Strings, ist lieber `std::stoi`oder der Leseoperator `>>` eines stream-Objektes (wie `std::cin`oder ein Objekt der Klasse `std::stringstream`) zu verwenden. `boost::lexical_cast` existiert ebenfalls.

### Kopierverhalten

Die Container der Standardbibliothek implementieren das Kopierverhalten intuitiv.

    std::vector<int> a, b;
    b = a; // hier wird jedes Element kopiert

Es kommt allerdings auf die konkrete Implementierung des Zuweisungsoperators des Elemettyps an, ob Daten tatsächlich kopiert werden oder nicht. Ein Basisdatentyp wie `int` oder ein struct wird kopiert. Möchte man das Kopieren von Daten vermeiden, ist das Weitergeben von Daten mit Hilfe von Referenzen möglich.

### Referenzen

Referenzen sind wie Zeiger mit impliziter (de)referenzierung. Sie sind praktisch bei Funktionen, welche auf Referenzparametern arbeiten sollen oder bei der weitergabe von Daten ohne Kopie.  
Das Verwenden von konstanten Referenzen gibt dem Übersetzer mehr Möglichkeiten, die Ausführungsgeschwindigkeit zu verbessern.  
Referenzen können auch als "Alias" verwendet werden, um den Quelltext übersichtlicher zu gestalten.

#### Beispiel

    /**
     * @file referencevspointerdemo.cpp
     * @brief Beispielprogramm zur Demonstration von Referenzen und Pointern.
     */

    #include <iostream> // für std::cout

    /**
     * Funktion zur Demonstration eines traditionellen Referenzparameters.
     */
    void inkrementiere_zeiger(int * i) {
        (*i)++; // explizites Dereferenzieren
    }
    
    /**
     * Funktion zur Demonstration eines modernen Referenzparameters.
     * Die Daten des Parameters werden nicht kopiert.
     */
    void inkrementiere_referenz(int & i) {
        i++;
    }
    
    /**
     * Einstiegspunkt zur Demonstration von Referenzen und Pointern.
     */
    int main(int argc, char *argv[]) {
        int zahl = 0;
        int & kopie = zahl; // hier wird eine Referenz erzeugt
        inkrementiere_zeiger(&zahl); // expliziter Adressoperatror für traditionelle Referenz
        inkrementiere_referenz(zahl); // implizite Referenz definiert durch Funktion
        kopie++; // arbeiten auf Referenz
        std::cout << i << std::endl; // hier wird 3 ausgegeben
    }

Im Gegensatz zu einem Zeiger kann eine Referenz nie NULL sein. Vorsicht ist beim Arbeiten mit Referenzen aber dennoch geboten: Stirbt das referenzierte Objekt (weil es seine Gültigkeit verliert oder explizit zerstört oder gelöscht wird), dann führt ein Zugriff auf die Referenz zu einem Absturz.

### Funktoren

Seit C++11 werden Aspekte der funktionalen Programmierung durch verschiedene Konzepte unterstützt, unter anderem: Funktoren beziehungsweise anonyme "Lambda" Funktionen und C-kompatible Funktionszeiger.

#### Beispiel

    /**
     * @file funktoren.cpp
     * 
     * Beispiel für die Deklaration eines Funktionstypen und 
     * die Definition eines Funktors durch einen Lambda-Ausdruck.
     */

    #include <iostream> // für std::cout
    #include <functional> // für std::function

    /**
     * Addiert 1.
     */
    int increment(int i) {
        return i+1;
    }

    /**
     * Einstiegspunkt, zur Demonstration der Verwendung eines Funktors.
     */
    int main(int argc, char *argv[])
    {
        // definiert den Typ des Funktors für den Bezeichner "operation":
        std::function<int(int)> operation;
        operation = increment; // setzt die auszuführende Operation

        int zahl = 0;
        zahl = operation(zahl); // führt die Operation aus
        std::cout << zahl << std::endl; // gibt 1 aus
        
        int multiplikator = 2;
        operation = // "operation" mit Lambda-Ausdruck belegt:
            [multiplikator] // "multiplikator" wird als konstanter Wert gefangen
            int(int i) // beim Aufruf wird ein int erwartet und ein int zurückgegeben
            {return i*multiplikator;} // Funktionsrumpf
            ; // Ende der Zuweisung auf Bezeichner "operation"
        zahl = operation(zahl);
        zahl = operation(zahl);
        zahl = operation(zahl);
        std::cout << zahl << std::endl; // gibt 8 aus
    }
