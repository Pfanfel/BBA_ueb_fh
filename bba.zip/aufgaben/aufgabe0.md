Diese Aufgabe stellt den Einstieg in die Programmierung von
bildorientierten Anwendungen in C﻿++ mit Open﻿CV dar. Das Verarbeiten von
Kommandozeilenparametern sowie das Laden, Organisieren, Anzeigen,
Ausgeben und Speichern von Bildern steht im Mittelpunkt.

Beim Bearbeiten dieser Aufgabe ist zu beachten, dass die
Rahmenbedingungen zu Richtlinien und Bewertung für alle Aufgaben gelten.

Diese Aufgabe 0 ist zum Kennenlernen des Ablaufs. Eine Besonderheit ist,
dass die Bewertung nicht in das Endergebnis eingeht. Der Basisteil muss
dennoch erfüllt werden, da hier eine solide Grundlage für die spätere Arbeit
vorbereitet werden muss.

#### Aufgabenstellung

Dies ist die Gliederung die konkreten Teilaufgaben folgen in den
weiteren Abschnitten.

Basisteil:

 *  Parameterverarbeitung
 *  Bild Laden (Graustufen)
 *  Bild auf der Standardausgabe ausgeben
 *  Organisieren der geladenen Bilder als Stapel
 *  Identitäts-Filter

Bewertungsteil:

 *  Mindestens drei automatische Tests (3 Punkte)
 *  Bild Laden (Farbigkeit automatisch erkennen) (1 Punkt)
 *  Speichern in Datei (1 Punkte)
 *  Open﻿CV GUI: Bild anzeigen (2 Punkte)
 *  C﻿++: Anonyme Funktionᵃ (2 Punkte)

##### Details

Das Programm muss Kommandozeilenparameter verarbeiten können. Das genaue
Format wird auf der Seite Parameter beschrieben.

Der Kommandozeilenparameter `--input <Dateiname>` lädt ein Bild. Zum
Laden eines Bildes soll Open﻿CV verwendet werden. Die zu verwendende
Funktion ist selbst zu recherchieren.  
**ACHTUNG:** Open﻿CV geht davon
aus, dass mit Farbbildern gearbeitet wird und wandelt daher beim Laden
jedes Bild standardmäßig in Farbbilder um. Das Bild soll jedoch
unverändert geladen werden. Das ist mit Hilfe des Setzen eines ebenfalls
zu recherchieren Flags möglich. Für den Basisteil ist es ausreichend, 
nur Graustufenbilder zu unterstützen. Für den Punkt "Farbigkeit automatisch 
erkennen" sollen `--show` und `--output` so erweitert werden, dass sie auch 
farbige Bilder anzeigen bzw. speichern können. Standard für Filter bleibt 
das Graustufenbild.

TODO: Lieber explizit `--printpxm` anstelle von `--output -`?
TODO: `--printraw` für `std::cout << img`.

Der Kommandozeilenparameter `--output -` gibt ein Bild auf der
Standardausgabe aus. Das Bild wird vom Bilderstapel entfernt. Zum
Ausgeben des Bildes auf der Standardausgabe soll `std::cout` verwendet
werden. Das Datenformat muss der Definition der [Portable
Anymap](https://de.wikipedia.org/wiki/Portable_Anymap) (PNM) in der
menschenlesbaren ASCII-Variante genügen. Funktionen aus Open﻿CV dürfen, müssen aber nicht verwendet
werden. Es ist nicht erlaubt, das Bild als Datei zu schreiben, wieder in den Speicher zu
lesen und dann auszugeben.

Der Kommandozeilenparameter `--output <Dateiname>` schreibt ein Bild in
die angegebene Datei. Das Format wird duch die Dateiendung ausgewählt.
Zum Schreiben des Bildes soll Open﻿CV verwendet werden. Die zu
verwendende Funktion ist selbst zu recherchieren.

Der Filter `--identity` beschreibt die Identitätsfunktion. Der
Filter greift auf jeden Bildpunkt einmal zu, ändert die Werte jedoch
nicht und hat somit keinen sichtbaren Effekt. Der Filter soll als
Ausgangspunkt für spätere Filter aber dennoch implementiert werden. Als
Signatur wird `void identity(cv::Mat &)` empfohlen.

Der Kommandozeilenparameter `--show` sorgt für die Anzeige des Bildes
mit Hilfe von `cv::imshow` und `cv::waitKey`. Die Programmausführung
wird angehalten, bis eine Taste gedrückt wird. Das Bild wird nicht vom
Bilderstapel entfernt.

Die in kommenden Aufgaben zu schreibenden Filter sind im Aufbau sehr
ähnlich. Redundanz soll aber vermieden werden. Daher soll mit Hilfe von
Funktionsobjekten Flexibiltät geschaffen werden.

Es dürfen mehrere Bilder geladen werden. Die Bilder sind in einem Stapel
zu organisieren. Details dazu sind den Hinweisen weiter unten zu
entnehmen.

#### Hinweise

##### Programmorganisation

Das Programm läuft in zwei Phasen ab.

1.  Parameterverarbeitung (parsen).
2.  Angeforderte Operationen durchführen.

##### Parameterverarbeitung

Während der Parameterverarbeitung werden die Kommandozeilenparameter
interpretiert. Aus den C-Strings soll eine Liste durchzuführender
Operationen erstellt werden. Das Programm wird nur mit gültigen Eingaben
versorgt. Gerade dort, wo es aufwändig ist, muss keine Prüfung der
Eingaben erfolgen. Die Parameterverarbeitung soll ein eigenes Modul
haben.

Der Aufruf

    bba --input eingabe.pgm --identity --output ausgabe.pgm

sorgt Progammseitig für die Kommandozeilenparameter in einem C-Array von
C-Strings:

    {"bba", "--input", "eingabe.pgm", "--identity", "--output", "ausgabe.pgm"}

Der Parser erstellt daraus eine Liste von Operationen. Die Arbeit mit
C-Arrays und C-Strings ist unbequem und soll gemieden werden. Hinweise
hierzu befinden sich auf der Seite für C﻿++. Es
reicht ein sehr einfacher LL1-Parser: Anhand des gerade betrachteten
Symbols kann sofort erkannt werden, welches Symbol als nächstes zu
erwarten ist.

 *  `--input` erwartet einen Parameter vom Typ string als Dateinamen

 *  `--output` erwartet einen Parameter vom Typ string als Dateinamen

 *  `--identity` hat keine Parameter. Später werden die Filter-Optionen als string vorliegen
    und sollen in float gewandelt werden.

Die Liste von Operationen könnte so aussehen (Pseudocode):

    {
       Operation (Typ: Bild Laden, Dateiname: "eingabe.pgm"),
       Operation (Typ: Identitäts-Filter anwenden, Liste der Parameter: {}),
       Operation (Typ: Bild Speichern, Dateiname: "ausgabe.pgm")
    }

Die Richtlinien sind einzuhalten. Die konkrete Umsetzung des Parsers und
den eigenen Datentypen (insbesondere die der Liste von Operationen)
unterliegt keinen weiteren Einschränkungen. Zum Laden und Speichern von
Bildern sollen die Open﻿CV Funktionen verwendet werden.

ᵃ) Alternativ darf objektorientiert mit Klassen gearbeitet werden. Es ist im Rahmen dieses Praktikums erlaubt, aber nicht notwendig, eigene Klassen zu definieren. Manche Teilnehmer empfinden das als einfacher, andere als schwieriger. Beachtet Object Slicing, benutzt Smart Pointers anstelle von nackten Zeigern und benutzt sie auch nur dort, wo es notwendig ist.

##### Operationsausführung

Die Liste der angeforderten Operationen wird dem Hauptprogramm
übergeben. Das Hauptprogramm arbeitet die Liste sequentiell ab.
Eingaben, Zwischenergebnisse und Endergebnisse werden auf einem
Bilderstapel organisiert. Gemäß der oben stehenden Liste soll das
Programm so ablaufen:

1.  Programmstart.  
    Der Bilderstapel ist leer.

2.  Operation "Bild Laden" wird ausgeführt.  
    Das geladene Bild wird auf den Bilderstapel gelegt.  
    Der Bilderstapel enthält das geladene Bild.

3.  Operation "Bild Filtern" wird ausgeführt. Filter ist der
    Identitäts-Filter.

    1.  Das oberste Bild wir vom Bilderstapel genommen.
    2.  Der Identitäts-Filter arbeitet auf dem Bild.
    3.  Das Ergebnisbild wird auf den Bilderstapel gelegt.

    Der Bilderstapel enthält das gefilterte Bild.  
    Es ist zu bemerken, dass der Filter selbst nicht direkt den Stapel
    manipuliert.

4.  Operation "Bild Speichern" wird ausgeführt.  
    Dabei wird das oberste Bild von Stapel entfernt.  
    Der Bilderstapel ist leer.

Das Verwenden eines solchen Bilderstapels wird später auch komplexe
Filter erlauben, welche mehr als ein Bild verarbeiten. Die Sequenz der
Operationen ist dabei als Postfixnotation ("polnische Rückwärtsnotation") 
zu verstehen. Verwendet ein Filter mehrere Bilder zur Eingabe, werden 
sie alle vom Stapel entfernt, bevor die Ergebnisbilder auf den Stapel 
gelegt werden.

##### Funktionsobjekte

Es ist möglich, mit an Variablen gebundenen anonymen "lambda" Funktionen
zu arbeiten, um Redundanz zu vermeiden. Das Einführen von Variablen des
Typs `std::function` ist gewünscht, aber nicht Pflicht. Ein Prototyp der
Funktion zur Manipulation jedes einzelnen Pixels kann so aussehen:

    void for_each_pixel(cv::Mat & m, /* TODO: Typdefinition für Funktionsobjekt hier einfügen */ f) {
        /* TODO: Iteration über jede Koordinate (x,y) in m */ {
            f(m, y, x);
        }
    }

Der Filter identity kann so implementiert werden:

    for_each_pixel(m, /* TODO: anonyme Identitätsfunktion hier definieren */ );

Später können zusätzliche Parameter bei der Definition der Funktion
gefangen werden, sodass die Signatur der Funktion für alle Filter gleich
ist.

##### Implementierungsbeispiel

Ein Beispiel für einen Ansatz zur Implementierung wird während der Aufgabenvorstellung präsentiert.

#### Aufrufbeispiele

Die Lösung wird mindestens mit diesen Aufrufen getestet:

    bba --input eingabe.pgm # Bild laden und vergessen
    bba --input eingabe.pgm --output - # Ausgabe auf Standardausgabe

    bba --input eingabe.pgm --identity --output - # den Identitäts-Filter auf ein Bild anwenden

    bba --input eingabe1.pgm --input eingabe2.pgm --output - --output - # Funktion des Stacks prüfen

    bba --input eingabe.pgm --identity --identity --output - # mehrere Filter hintereinander anwenden

    bba --input eingabe.pgm --output ausgabe.png # in anderem Dateiformat speichern
    bba --input eingabe1.pgm --input eingabe2.pgm --output ausgabe2.pgm --output ausgabe1.pgm # Funktion des Stacks prüfen

    bba --input eingabe.pgm --show # Bild laden, anzeigen und vergessen
    bba --input eingabe.pgm --show --output - # Bild laden, anzeigen und Ausgeben

#### Gruppenzuordnung bei Abnahme

Initiale Verteilung fair erzeugt durch
[random.org](https://www.random.org/lists/?mode=advanced). Bei Bedarf
dürfen Tauschvorschläge individuell mit dem Abnehmer koordiniert werden.

Zeitslots:

1. 11:00
1. 11:30
1. 12:00
1. 12:30
1. 13:00

**Hermann "hoe" Höhne** – 🐧 (⊞)
