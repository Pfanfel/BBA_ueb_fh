Für jede Aufgabe gelten diese Richtlinien.

#### Organisatorisches

 *  Die Anmeldung zum Praktikum muss vor der Veröffentlichung der ersten Aufgabe erfolgen.
 *  Mit der Abgabe einer Lösung zur ersten Aufgabe wird die Anmeldung bindend. Ein nachträgliches Abbrechen der Teilnahme am Praktikum führt zum Eintrag "nicht bestanden". Das Praktikum darf drei mal wiederholt werden.
 *  Die Aufgaben werden in Gruppen zu je maximal zwei Studenten bearbeitet. Eine Gruppe muss gemeinsam alle Aufgaben bis zum jeweiligen Termin lösen.
 *  Alle Aufgaben werden fest vorgegeben.
 *  Zu jeder Aufgabe gibt es eine Aufgabenvorstellung, bei der Hinweise zur neuen Aufgabe gegeben werden.
 *  Jede Aufgabenstellung wird spätestens am Tag der Aufgabenvorstellung auf der entsprechenden Internetseite veröffentlicht.
 *  Das Forum ist regelmäßig zu lesen. Oft werden hier Mehrdeutigkeiten in Aufgabenstellungen eliminiert.

**ACHTUNG:** Als Vorbedingung muss die *Übung* "Systemnahe Programmierung" (in C) bestanden worden sein.

#### Abnahme

Vor dem Hintergrund der aktuellen Maßnahmen zur Verlangsamung einer Epidemie wird von körperlichen Treffen in der Fachhochschule abgesehen. Eine Abnahme vor Ort findet daher zunächst nicht statt. Diese Teile der Rahmenbedingungen für Abnahmen bleiben jedoch weiterhin in Kraft:

 *  Die Nutzung von SVN ist Pflicht!
     *  Alle für die Lösung notwendigen Quellen müssen *rechtzeitig zum im Moodle angegebenen Fälligkeitsdatum* der jeweiliden Aufgabe im SVN-Repository verfügbar sein. Beim Abnahmegespräch wird die Lösung aus dem SVN-Repository ausgecheckt. **ACHTUNG:** Das Fälligkeitsdatum liegt **vor** dem Datum des Abnahmegesprächs (der Abnehmer liest sich den Quelltext vorher durch).
     *  Jeder Gruppe ist ein SVN Repository an `https://svn.fh-wedel.de/repos/uebungen/bba/bba_xx` zugeordnet, wobei `xx` für die Gruppennummer steht.
     *  Nur Quellen und gegebenenfalls Testdaten sind in SVN einzupflegen, jedoch keine Kompilate.
 *  Bei der Abnahme müssen alle Gruppenmitglieder anwesend sein. Alle müssen bei der Präsentation der Lösung aktiv mitwirken.  
    Sollte ein Gruppenmitglied wegen Krankheit entschuldigt fehlen, so muss der jeweils andere (soweit vorhanden) die Lösung allein präsentieren. Gegebenenfalls muss nach seiner Genesung auch das fehlende Mitglied die Lösung präsentieren und erklären können.

Diese Bedingungen gelten vorübergehend:

 *  Für jedes Abnahmegespräch gibt der Abnehmer einen Termin mit absoluter Zeitangabe und eine Technologie für ein Gespräch ohne körperliches Treffen vor. Die Teilnehmer sind angehalten, ihrerseits frühzeitig die technischen Voraussetzungen für eine Teilnahme am Gespräch zu schaffen.  
    Falls ein Abnahmegespräch trotz bester Bemühungen aller Beteiligten nicht zeitnah stattfinden kann, soll es später im Semester nachgeholt werden. Die Teilnehmer sind angehalten, Quelltextkommentare und gegebenenfalls Notizen so vorzubereiten, dass sie zu ihrer eigenen Arbeit auch Monate später noch kompetente Antworten geben können.

Sobald der Veranstaltungsbetrieb wie gewohnt aufgenommen werden kann, sollen die üblichen Bedingungen gelten:

 *  Das Abnahmegespräch findet jeweils an den am Ende der Aufgabenstellung genannten Terminen unter Linux an einem Rechner im RZ statt.

Es soll im Rahmen dieses Praktikums eine explizite Ankündigung geben, wenn die Richtlinen modifiziert werden.

#### Technische Vorgaben

Hier werden die technischen Vorgaben aufgelistet, welche beim Bearbeiten der Aufgaben einzuhalten sind.
 
##### Softwareumgebung

Mit diesen Versionen ist zu rechnen:

 *  g++ 7.5.0
 *  make 4.1
 *  OpenCV 3.2.0
 
Zum Übersetzen wird das vorgegebene Makefile verwendet.  
 
##### Code-Richtilinen

 *  Die Lösung muss zum Abgabezeitpunkt auf dem Rechner des Rechenzentrums unter Linux mit dem vorgegebenen Makefile ohne Fehler und Warnung übersetzbar sein. Es ist nicht notwendig, auf dem heimischen Rechner unter Linux zu entwickeln. Es wird aber oft als einfacher empfunden.
 *  Im Kopf jeder Quelle muss ein Kommentar Name und Matrikelnummern der Autoren enthalten.
 *  Jede implementierte Funktion ist mit allen sinnvollen Parameterwerten zu testen.
 *  Es ist in jeder Programmiersprache, besonders auch C++, möglich, den Quelltext so zu gestalten, dass er cool aussieht. Lesbarer Quelltext ist aber wichtiger.
 *  Nicht genutzter Code wird entfernt, nicht auskommentiert.
 *  Es wird als schlechter Stil angesehen, bei Fehlern das Programm abzuwürgen. Allerdings soll im Rahmen dieses Praktikums die Fehlerbehandlung nicht im Vordergrund stehen, also dürfen zur Laufzeit eigene Fehler mittels `std::runtime_error` als Ausnahmen geworfen werden. Eine Ausnahme muss nicht gefangen werden, sondern darf zum Programmabbruch führen.
    
##### Modularisierung

 *  Ein Modul ist eine Kombination von .cpp und .hpp Datei mit dem Modulnamen.
 *  Jedes Modul verwendet einen eigenen Namensraum.
 *  Die Verarbeitung der Kommandozeilenparameter ist in einem eigenen Modul mit einem sprechenden Namen wie `argparse` zu implementieren.
 *  Ungebundene Hilfsfunktionen, welche nicht einer bestimmten Aufgabe zugeordnet sind (beispielsweise das Schreiben von Bildern auf die Standardausgabe) sind in einem Modul mit einem Namen wie `util` zu implementieren.
 *  Die konkrete Implementierung zur Lösung einer spezifischen Aufgabe soll in einem separaten Modul geschehen.  
    Beispiel: Wird in Aufgabe 1 die Implementierung der Operation `inverse` gefordert, so soll es ein Modul (beispielsweise mit dem Namen `aufgabe1`) geben, welches die Funktion oder Methode `inverse` implementiert.
 *  Eine feinere Modularisierung darf vorgenommen werden. Das Zusammenfassen von gemeinsam genutzten Funktionen über Aufgabengrenzen hinweg ist ebenfalls erlaubt. Auf die Funktionen, welche zur Lösung der vorausgegangenen Aufgaben dieses Semesters implementiert worden sind, darf zugegriffen werden. Das muss aber nicht gemacht werden. Werden alte Module verwendet, sind die dafür notwendigen Dateien nochmals einzuchecken.
 *  Jede Funktion zur Bildbearbeitung soll ein spezifisches Interface besitzen: Es werden ein oder mehrere Bilder und die Parameter der Operation übergeben, jedoch keine komplexen Datenstrukturen, welche der Verwaltung des Programmes dienen.
 
