In dieser Aufgabe geht es um die bildweise Bearbeitung von Videos.
#### Aufgabenstellung

Basisteil:

 *  Video lesen und schreiben
 *  Feature verfolgen mittels Template Matching
 
<nolink>
Punkte:

 *  Stabilisierung durch iterative Anpassung der Vorlage (2 Punkte)
 *  zeitliche Stabilisierung (2 Punkte)
 *  Unterbereichsuche (1 Punkt)
 *  OpenCV GUI: Feature durch Anklicken auswählen (2 Punkte)
 *  Rückwärtskompatibilität: rotate, fold (auch values), linear (auch brightness, factor) können auf Video arbeiten (2 Punkte)

TODO: add und multiply für wasserzeichen / "senderlogo"?

##### Details

###### Basisteil

Für den Basisteil muss die Programmstruktur so angepasst werden, dass anstelle von Bildern auch Videos gelesen und geschrieben werden können.

Es ist überhaupt nicht sinnvoll und deswegen explizit nicht **nicht erlaubt**, das gesamte Video auf einmal in den Arbeitsspeicher zu laden. Dadurch wird die maximale Länge der zu verarbeitenden Videos unnötig durch die Größe des verfügbaren Arbeitsspeichers begrenzt.

Das Verwenden sämtlicher Funktionen aus OpenCV ist ohne Einschränkung erlaubt.

Es darf angenommen werden, dass alle Videos eine Bildrate von 25 verwenden.

 *  Videos

    Beispielaufrufe:

        bba --videoin test.avi --output firstframe.ppm # Speichert erstes Bild des Videos
        bba --videoin test.avi --output - # Gibt erstes Bild des Videos aus
        bba --videoin test.avi --framerate 25 --videoout out.avi # Schreibt Video unverändert
        bba --videoin test.avi --framerate 50 --videoout timelapse.avi # Erzeugt 2x Zeitraffer

 *  Filter `track`:  

    Der Filter verfolgt mittels Template Matching einen Bildbereich durch das Video und blendet einen Text ein. Der Effekt wurde in der BBC Serie "Sherlock" populär genutzt. Der Filter erwartet die Parameter `x y b r g b text`, wobei (x,y) einen Bildpunkt indiziert, b die Länge der Seite des quadratischen Musters, und (r,g,b) die Farbe angibt. Die Vorlage wird aus dem ersten Bilde des Videos extrahiert. Die Koordinate gibt dabei die Mitte an. Es wird erwartet, dass die Seitenlänge ungerade ist. `42 84 15 1 0 0 "Hier"` verfolgt den Bildbereich, welcher im ersten Bild um den Punkt (42,84) zu sehen ist. Der Text "Hier" wird rot in der Nähe eingezeichnet.

    **TODO:** Referenzbild anstelle von Koordinaten akzeptieren?  
    **TODO:** Bild anstelle von Text einblenden?  

    Beispielaufruf:
    
        bba --videoin test.avi --track 42 84 15 1 0 0 "Hier" --videoout track.avi

    Beispielausgabe:

    <video src="https://stud.fh-wedel.de/handout/H%C3%B6hne_Hermann/Bildbearbeitung%20und%20-analyse/Bildmaterial/Template%20Tracking/Beispielausgabe.mp4" controls autoplay>Beispiel für den Track-Filter: Kommentar an Person</video>

###### Bewertungsteil

 *  Mit Szenenwechseln im Video muss nicht gerechnet werden.

 *  Stabilisierung durch iterative Anpassung der Vorlage  
    Im Verlaufe eines Videos bleibt die zu verfolgende Vorlage nicht perfekt gleich. Schleichende Veränderungen können dafür sorgen, dass das Verfolgen "entgleist". Eine behutsame Aktualisierung der Vorlage schafft Abhilfe.
    
 *  zeitliche Stabilisierung  
    Das Finden der Vorlage im Bild ist keine vollkommen exakte Wissenschaft. Geringfügige Abweichungen können entstehen. Wegen Bildrauschen können benachbarte Positionen durchaus von einem Videobild zum nächsten hin und her "flattern". Das sieht wenig hübsch aus und kann verbessert werden, indem die aktuelle Position nicht nur anhand des jüngsten Videobildes bestimmt wird. Es ist möglich, die Position im Video im Kontext des zeitlichen Verlaufes zu sehen und zwecks Stabilisierung zu verrechnen.

 *  Unterbereichsuche  
    Wird jedes Videobild komplett nach der Vorlage durchsucht, dauert das unnötig lang. Die Suche kann auf einen angemessen großen Unterbereich eingeschränkt werden.
    
 *  Feature durch Anklicken auswählen  
    Eine Variante des Filters `track-gui` nimmt die gleichen Parameter, verzichtet jedoch auf die Koordinaten. Stattdessen wird beim ersten Bild des Videos ein Fenster mittels `cv::imshow` geöffnet. Auf diesem Fenster soll der Benutzer 1 Punkt anklicken, der als Zentrum der Vorlage gelten soll. Mit einem Tastendruck wird die Eingabe bestätigt und der Filter läuft weiter.
    
    Beispielaufruf:
    
        bba --videoin test.avi --track-gui 15 1 0 0 "Hier" --videoout track.avi

 *  Alte Filter

    Beispielaufrufe:
        
        bba --videoin dark.avi --brightness 0.25 --videoout videoout.avi # Hellt Video auf
        bba --videoin noisy.avi --values 3 3 1 1 1 1 1 1 1 1 1 --factor .111111 --fold --videoout videoout.avi # Entfernt Rauschen
        bba --videoin vertical.avi --rotate -90 --videoout horizontal.avi # Dreht Video

##### Hinweise

###### Basisteil

* Das Hauptprogramm kann so abgeändert werden, dass es in einer Endlosschleife über alle Bilder aller Videos läuft, bis mindestens ein Video keine weiteren Bilder liefern kann.
    * Ein Bild als Eingabe wird wie ein Video behandelt, welches endlos immer wieder das gleiche Bild liefert. 
    * Beim Speichern des Ergebnisses in ein Bild oder Ausgeben auf die Standardausgabe wird nur das erste Bild ausgegeben.
    * Beinhaltet die Eingabe ein statisches Bild, wird es sinnvollerweise nur einmal gelesen und dann nur noch geklont. Sind nur Bilder in der Eingabe und die Ausgabe ein Video, läuft das Programm endlos.
* Es ist erlaubt, zu Debugzwecken Bilder mittels `cv::imshow` und `cv::waitKey(t)` mit `t > 0` anzuzeigen.
* OpenCV kann eine Vielzahl von Videocontainern und Codecs unterstützen. Der genaue Funktionsumfang ist jedoch abhängig vom Kompilat, dem Betriebssystem und den darin zur Verfügung stehenden Funktionen. Auf den drei großen Plattformen funktioniert nur MJPEG in AVI zuverlässig. Ein [passend transcodiertes Video](https://stud.fh-wedel.de/handout/H%C3%B6hne_Hermann/Bildbearbeitung%20und%20-analyse/Bildmaterial/Template%20Tracking/eingabe.avi) ist auf dem Handoutserver zu finden.
* Dieser Effekt ist eher künstlerischer Natur, weshalb automatische Tests nicht notwendig sind. Ein Testprotokoll mit Eingabe- und Ergebnisvideo ist dennoch wichtig.
* <a class="nomediaplugin" href="https://www.youtube.com/watch?v=uFfq2zblGXw&t=146">Dieses Video</a> erläutert die semantischen Hintergründe des Effekts.

###### Bewertungsteil

Die Bilder von Videos werden von OpenCV immer als Farbbilder verstanden. Es sollte nicht notwendig sein, die Implementierung der alten Filter zu ändern. Sie sollen vielmehr auf jeden Farbkanal separat angewendet werden.

###### Erzeuger in C++

Für das Erweitern des bestehenden Gerüsts bietet sich das "Erzeuger-Muster" an. Durch die Erweiterung können nicht nur einzelne Bilder, sondern ganze Bildsequenzen (Videos) bearbeitet werden. Für ein konkretes Beispiel für Erzeuger in C++
</nolink> habe ich einen [Consolecast](https://stud.fh-wedel.de/handout/H%C3%B6hne_Hermann/Bildbearbeitung%20und%20-analyse/Screencasts/editor.html?cast=bba_6-generator) vorbereitet. Der in der Aufzeichnung entwickelte Quelltext ist als generator_komplett.cpp gegeben.

Ich war mir absolut sicher, dass `std::move` in der Capture Group der mutablen Lambdas notwendig ist. Dem ist offenbar nicht so. 🤷

#### Quellenverzeichnis

* [Personen reden im Cafe](https://www.pexels.com/video/man-and-woman-discussing-work-outdoors-2795168/)
* [Personen reden auf dem Fahrstuhl](https://www.pexels.com/video/two-women-talking-inside-an-elevator-going-up-3044787/)

#### Gruppenzuordnung bei Abnahme:

Rotation der Verteilung von voriger Abnahme.  

Zentral verwaltete Abnahmetermine gibt es für diese Aufgabe nicht, weil sie innerhalb der vorlesungsfreien Zeit stattfinden. Bitte kontaktieren Sie Ihren Abnehmer baldmöglichst und handeln Sie *bis zum Ende der Kalenderwoche 33* einen Termin aus. Bedenken Sie nicht nur Ihre Prüfungen, sondern auch Ihre Urlaubswünsche und die der Abnehmer. Der **9. Oktober 2020 ist der spätestmögliche Termin** für Abnahmen. 

Falls Sie in irgendeiner Klausur den letzten Versuch vor sich haben und damit möglicherweise auch eine ***-Prüfung droht oder ins Praxis-, Auslands- oder Urlaubssemester gehen wollen, dann gelten besondere Regeln. Bitte melden Sie sich zeitnah.

**Hermann "hoe" Höhne** – 🐧 (⊞)
