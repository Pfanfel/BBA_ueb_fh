Diese Seite erläutert die Details des Systems zur Bewertung.

#### Abnahme

Die Lösung zu einer Aufgabe muss fristgerecht ins Versionskontrollsystem eingepflegt werden. Es gibt einen Abgabezeitpunkt, welcher für alle Gruppen gilt. Die eigentliche Bewertung einer Aufgabe findet zwecks Kontrolle der Eigenleistung im Rahmen eines Abnahmegespräches statt. Die Termine werden je Gruppe festgelegt. 

Das *gesamte* Programm muss von *allen* Gruppenteilnehmern erklärt werden können. Der Quelltext soll den Code-Richtlinien entsprechen. Weitere Details zu den sind unter allgemeine Richtlinen erläutert.

#### Aufgabenteile

Die notwendige Programmfunktionalität wird im Rahmen jeder Aufgabe definiert. Jede Aufgabe beinhaltet einen Basisteil und einen Bewertungsteil.

Begutachtet wird die Lösung, welche zum Abgabezeitpunkt in der Versionskontrolle vorliegt.

##### Basisteil

Der Basisteil definiert den minimal erwarteten Umfang an Funktionalität. Der Basisteil muss zufriedenstellend gelöst werden, ansonsten ist eine weitere Bewertung nicht möglich.

Darüber hinaus muss für eine Lösung des Basisteils gelten:

 *  Der Quelltext wird ohne Fehler übersetzt (Warnungen des Übersetzers gelten als Fehler)
 *  Das Kompilat verarbeitet jeden in der Aufgabenstellung veröffentlichten gültigen Programmaufruf. Dazu gehört:
    *  Das Programm arbeitet technisch fehlerfrei und beendet sauber.  
       Gegenbeispiele:
        *  Programm stürtzt ab (beispielsweise wegen eines Speicherzugriffsfehlers).
        *  Programm hängt in Endlosschleife oder Endlosrekursion.
    *  Das Ergebnis wird wie angefordert als Bild abgespeichert bzw. ausgegeben.  
       Gegenbeispiele:
        *  Ergebnis wird nur teilweise oder gar nicht ausgegeben.
        *  Ergebnis wird unter anderem Dateinamen gespeichert.
        *  Ergebnis wird in anderem Dateiformat bereitgestellt.
        *  Ausgabe ist nicht durch ein etabliertes Graphikprogramm wie ImageMagick's `display` lesber.

**HINWEIS:** Die Aufgaben bauen teilweise aufeinander auf. Der Basisteil beinhaltet Funktionen, welche in späteren Aufgaben benötigt werden. Wird der Basisteil einer Aufgabe nicht gelöst, kann auch die folgende Aufgabe nicht gelöst werden. Daher kann das Praktikum nicht bestanden werden, wenn ein Basisteil nicht gelöst wurde.

##### Bewertungsteil

Der Bewertungsteil definiert weitere Funktionalität.

Die zusätzlichen Funktionen sind mit Punkten ausgezeichnet. Das Umsetzen der Funktion wird mit dem Erhalt von Punkten belohnt. Der Wert jeder Funktion ist angegeben. Das perfekte Umsetzen aller Funktionen des Bewertungsteils einer Aufgabe führt zur vollen Punktzahl für die Aufgabe.

#### Bewertung

Nachdem der Basisteil gelöst wurde und die Punkte des Bewertungsteils gutgeschrieben worden sind, wird die Qualität des Quelltextes kontrolliert. Dabei können durch den Abnehmer Punkte abzegogen werden.

##### Beispiele für Gründe für Punktabzug

 *  Schlechte Bezeichner  
    Variablenbezeichner wie `var` oder Funktionsnamen wie `doStuff` sind keine sprechenden und selbsterklärenden Bezeichner.

 *  Unzureichend implementierte Filter  
    Arbeitet ein Filter nicht so, wie in der Vorlesung angegeben, können Punkte abgezogen werden. Sollten Definitionen der Vorlesung von anderen geläufigen Definitionen abweichen, ist in einem Quelltextkommentar sicherheitshalber darauf hinzuweisen, woher die verwendete Definition stammt. 
    Arbeitet ein Filter nur unter bestimmten, nicht explizit geforderten Einschränkungen (z.B. "Bild muss quadratisch sein" oder "Parameter ist float, arbeitet aber nur mit positiven ganzen Zahlen"), können Punkte abgezogen werden.
    
 *  Verwendung von globalen Variablen  
    Alle Funktionen sollen ausschließlich auf ihren Eingaben arbeiten und ihre Ergebnisse entweder über die normale Rückgabe liefern oder über Referenzparameter weitergeben. Dabei ist auch darauf zu achten, dass keine unnötigen Parameter übergeben werden. Die Nutzung einer globalen "Superstruktur", welche einfach an jede Funktion übergeben wird, ist daher explizit unzulässig.

 *  Speicherlecks  
    Im Rahmen des Praktikums ist es nicht notwendig, Speicher explizit mit `new` oder `malloc` zu allokieren. Sollte dennoch Speicher auf dem Heap reserviert werden, muss der selbstverständlich auch korrekt verwaltet werden. Etwaige Speicherlecks werden daher definitiv mit Punktabzügen bestraft.

 *  Importe in den globalen Namensraum  
    Für jede Funktion und Klasse soll auf den ersten Blick eindeutig erkennbar sein, aus welcher Bibliothek sie kommt. Der Import von Bezeichnern in den globalen Namensraum mit `using namespace xyz;` ist daher unzulässig. Der Import von C-Bibliotheken und das Verwenden von C-Funktionen wie `strcmp` oder `memcpy` ist ebenfalls verboten.
    
 *  Unnötiger Einsatz nackter Zeiger  
    C ist aus "Systemnahe Programmierung" und "Computergraphik" bekannt. Dazu gehören unbequeme Eigenarten, wie Zeiger, die auf NULL gesetzt sein können. Oder Zeichenketten, deren Ende mit einem Nullbyte markiert wird. Dies soll nicht der Fokus in der Bildbearbeitung sein. C++ bringt automatische Speicherverwaltung mit, diese soll auch genutzt werden. Der Umgang mit Zeigern ist daher verboten. Ausnahmen müssen individuell begründet werden.  
    Es ist möglich, aber im Rahmen dieses Praktikums nicht notwendig, eigene Klassen zu definieren. Wer eigene Klassenhierarchien verwendet, kann Opfer von [Object Slicing](http://stackoverflow.com/questions/274626/what-is-object-slicing) werden. Nur an dieser Stelle ist das Verwenden von Zeigern eindeutig sinnvoll. Die Objekte müssen verwaltet und korrekt zerstört werden. `std::unique_ptr` dürfen gerne verwendet werden.
    
 *  Verwenden von dynamischen C Arrays  
    Gründe ähnlich zum vorigen Punkt. Dynamische C Arrays sind mit Vorsicht zu [handhaben](https://stackoverflow.com/questions/11656532/returning-an-array-using-c). Deswegen sollen sie in diesem Praktikum gar nicht verwendet werden. Für die lineare Datenstrukturen bietet sich `std::vector` an. Für mehrdimensionale Datenstrukturen `cv::Mat`.
    
 *  Große Abweichungen  
    Noch mehr als die Bildbearbeitung ist die Bildverarbeitung an vielen Stellen nicht perfekt exakt. In den meisten Fällen sind Abweichungen von ±1 akzeptabel. Es ist dem Abnehmer vorbehalten, bei großen Abweichungen oder vermeidbaren Fehlern dennoch Punkte abzuziehen.

 *  Code-Verdopplung  
    Werden für zwei Koordinaten oder mehrere Filter dieselben Befehle ausgeführt (z.B. Bereichsüberprüfung, Iterieren), so ist die gemeinsam genutzte Funktionalität in eine Funktion auszulagern, sodass redundante Implementierungen vermieden werden.

 *  Unpassende Datenstrukturen  
    Es ist nicht sinnvoll, zweidimensionale Daten (wie Beispielsweise Matrizen) zu plätten, damit sie in eindimensionale Datenstrukturen passen.

 *  Unübersichtliche Schnittstellen  
    Es ist nicht hilfreich, viel Funktionalität in eine einzige "do-everything" Funktion zu schreiben, welche intern wiederum mit beispielsweise `switch` die eigentliche Funktion kapselt.

 *  Fremdquellen ohne Verweis  
    Verwendung von Quelltext aus **öffentlichen** Quellen (z.B. aus einem Eintrag eines Blogs oder aus einer Antwort aus einem Forum) ist stets mit Quellenangabe innerhalb eines Quelltextkommentars zu markieren. Der Quelltext muss erläutert werden können. Andernfalls ist mit Punktabzug zu rechnen.  
    Das unreflektierte Verwenden vom Quelltext anderer Gruppen, das Veröffentlichen des eigenen Quelltextes vor der Abgabe, oder das Anheuern eines Ghostwriters ist natürlich dennoch strengstens untersagt und führt als Täuschungsversuch zum Nichtbestehen des Praktkiums.

Diese Regeln werden nicht aufgestellt, um die Arbeit schwieriger zu machen. Vielmehr sollen die Teilnehmer in eine Richtung gelenkt werden  sauberen, robusten Quelltext zu schreiben.

### Benotung

Am Ende des Praktikums werden die Punkte der Bewertungsteile aller vier bewerteten Aufgaben ungewichtet summiert und entsprechend der folgenden Tabelle auf eine Note abgebildet:

|PUNKTE|NOTE
|--|--|
|0|4.0|
| 1 bis  4|3.7|
| 5 bis  8|3.3|
| 9 bis 12|3.0|
|13 bis 16|2.7|
|17 bis 20|2.3|
|21 bis 24|2.0|
|25 bis 28|1.7|
|29 bis 32|1.3|
|33 bis 36|1.0|
