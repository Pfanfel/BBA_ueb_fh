Beim "Template Matching" wird ein Bild durchsucht nach einem bekannten Teilausschnitt – ähnlich wie beim "Block Matching" oder wie ein Wort in einem Satz gesucht werden kann. Der Teilausschnitt wird hierbei als "Template" (Vorlage) bezeichnet.

Der Algorithmus sucht in der Regel die Position, an welcher die Vorlage die größte Übereinstimmung mit dem Bild hat. Dafür wird die Vorlage an jede Position im Bild bewegt (ähnlich wie bei den lokalen Filtern in Aufgabe 2). Der dieser Position entsprechende Teilausschnitt des Bildes wird mit der Vorlage verglichen. Dabei wird für jedes Element die absolute Differenz berechnet (wie bei `adiff` in Aufgabe 1). Die Summe der absoluten Differenzen ist die Filterantwort an dieser Position.  
<img src="https://stud.fh-wedel.de/handout/Höhne_Hermann/Bildbearbeitung und -analyse/Bildmaterial/Template Tracking/template-matching.svg">  
Andere Metriken wie die Wurzel der Summe der Quadrate der Differenzen sind weit verbreitet. Auch das Normieren (Teilen durch die Anzahl an Pixeln oder theoretisches Maximum der Antwort) ist möglich.

In Farbbildern wird die Antwort für jeden Kanal einzeln berechnet und die Filterantwort kombiniert. Es kann im RGB Farbraum oder in einem anderen, z.B. HSV gerechnet werden. Die Antworten der einzelnen Kanäle können gleichmäßig oder gewichtet verrechnet werden.

Das konkrete vorgehen wird je nach Anwendungsfall ausgewählt.

Beispiel mit Bild, Vorlage (Originalgröße) und Filterantwort:  
<img src="https://stud.fh-wedel.de/handout/H%C3%B6hne_Hermann/Bildbearbeitung%20und%20-analyse/Bildmaterial/Template%20Tracking/template-matching_image.jpg" style="max-width: 40%; max-height: 80vh;">
<img src="https://stud.fh-wedel.de/handout/H%C3%B6hne_Hermann/Bildbearbeitung%20und%20-analyse/Bildmaterial/Template%20Tracking/template-matching_template.png">
<img src="https://stud.fh-wedel.de/handout/H%C3%B6hne_Hermann/Bildbearbeitung%20und%20-analyse/Bildmaterial/Template%20Tracking/template-matching_response.png" style="max-width: 40%; max-height: 80vh;">

In einem weiteren Schritt wird die Filterantwort nach dem kleinsten Wert durchsucht. Dies ist die Position, an der die Vorlage am besten mit dem Bild übereinstimmt. Im Beispielbild sieht man die Positionen mit geringen Differenzwerte als "schwarze Löcher" in der nähe des Kragens.

Weitere Beispiele für Anwendungsmöglichkeiten finden sich in der [OpenCV Dokumentation](https://docs.opencv.org/3.2.0/de/da9/tutorial_template_matching.html) oder den [OpenCV (Python) Tutorials](https://opencv-python-tutroals.readthedocs.io/en/latest/py_tutorials/py_imgproc/py_template_matching/py_template_matching.html).
