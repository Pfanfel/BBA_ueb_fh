In dieser Aufgabe geht es um pixelweise Operationen, Histogramm-Transformation und -analyse sowie Datentypen und ihre Wertebereiche.

Beim Bearbeiten dieser Aufgabe ist zu beachten, dass die Rahmenbedingungen zu Richtlinien und Bewertung für alle Aufgaben gelten.

TODO: Auf uchar bleiben
TODO: Farbbilder haben wollen?

#### Aufgabenstellung

Basisteil:

 *  Wertbegrenzung
 *  lineare Punktoperatoren: brightness, factor, linear
 *  Histogramm

Bewertungsteil:

 *  Kontrast (1 Punkt)
 *  Gamma (1 Punkt)
 *  Summe, Differenz, absolute Differenz (3 Punkte)
 *  Normieren (1 Punkt)
 *  Summen-Histogramm (1 Punkt)
 *  Bildanalyse: Belichtungsprüfung (2 Punkte)  
    Kreativvariante Bildanalyse: Jahreszeitenbestimmung

##### Details

 *  In dieser Aufgabe werden nur Graustufenbilder gelesen und geschrieben.

 *  Der Wertebereich für die auf der Kommandozeile übergebenen Intensitätswerte der Filteroptionen sei [0.0, 1.0], wobei ein Intensitätswert von 0.0 einen schwarzen Pixel und ein Intensitätswert von 1.0 einen weißen Pixel beschreibt. Die nachfolgenden Funktionsdefinitionen erwarten ebenfalls diesen Wertebereich. Mehr zum Thema Wertebereiche ist im Abschnitt "Hinweise" weiter unten zu finden.  

 *  Filter `clamp`  
    Dieser Filter begrenzt alle Werte auf den Wertebereich [0, 1]. Viele Filter können Werte erzeugen, welche außerhalb des Wertebereichs liegen. Vor dem Speichern oder dem Anzeigen sollte daher der Filter `clamp` aufgerufen werden.  
    <img src="http://intern.fh-wedel.de/~hoe/typolike/bba-clamp.svg" alt="$f(i)=\left\{\begin{array}{lll}0&amp;x&lt;0\\1&amp;x&gt;1\\i&amp;sonst\end{array}\right.$" style="height:4.5em;">

    Beispielaufrufe in den folgenden Beispielen.

 *  Filter `brightness`  
    Dieser Filter manipuliert die Helligkeit des gesamten Bildes.  
    <img src="http://intern.fh-wedel.de/~hoe/typolike/bba-brightness.svg" alt="$f(i)=i+a$" style="height:1.5em;">

    Beispielaufruf:  

        bba --input test.pgm --brightness 0.25 --clamp --output -
        bba --input test.pgm --brightness -0.25 --clamp --output -

 *  Filter `multiply`  
    Dieser Filter manipuliert die Intensitäten des gesamten Bildes anhand eines Faktors.  
    <img src="http://intern.fh-wedel.de/~hoe/typolike/bba-factor.svg" alt="$f(i)=i·a$" style="height:1.5em;">

    Beispielaufruf:  

        bba --input test.pgm --multiply 0.25 --output -

  * Filter `divide`  
    TODO: Für explizites Normieren der Filterantworten in Aufgabe 2

 *  Filter `linear`  
    Dieser Filter ist die Verallgemeinerung von `brightness` und `factor`. Er führt eine lineare Histogrammtransformation durch.  
    <img src="http://intern.fh-wedel.de/~hoe/typolike/bba-linear.svg" alt="f(i)=ai+b" style="height:1.5em;">

    Beispielaufruf:  

        bba --input test.pgm --linear 1.0 0.125 --clamp --output -
        bba --input test.pgm --linear -1.0 1.0 --output -

    Wobei der erste Parameter die Steigung und der zweite Parameter den Achsenabschnitt angibt.

 *  Filter `contrast`  
    Dieser Filter ändert den Kontrast des gesamten Bildes anhand einer linearen Abbildung.  
    <img src="http://intern.fh-wedel.de/~hoe/typolike/bba-contrast.svg" alt="$f(i)=(i-0.5)·a+0.5$" style="height:1.5em;">

    Beispielaufruf:  

        bba --input test.pgm --contrast 2.0 --clamp --output -
        bba --input test.pgm --contrast 0.5 --output -

 *  Filter `gamma`  
    Dieser Filter führt eine Gamma-Anpassung durch.  
    <img src="http://intern.fh-wedel.de/~hoe/typolike/bba-gamma.svg" alt="$f(i)=i^{a}$" style="height:1.5em;">

    Beispielaufruf:  

        bba --input test.pgm --gamma 0.5 --output -
        bba --input test.pgm --gamma 2.0 --output -

 *  Filter `add`  
    Dieser Filter summiert zwei Bilder pixelweise.

    Beispielaufruf:  

        bba --input a.pgm --input b.pgm --add  --clamp --output -

 *  Filter `sub`  
    Dieser Filter subtrahiert zwei Bilder pixelweise.

    Beispielaufruf:  

        bba --input a.pgm --input b.pgm --sub --clamp --output -

    Dies führt pixelweise a-b aus.

 *  Filter `adiff`  
    Dieser Filter bestimmt pixelweise die absolute Differenz zweier Bilder.

    Beispielaufruf:  

        bba --input a.pgm --input b.pgm --adiff --clamp --output -

    Dies führt pixelweise |a-b| aus.

 *  Filter `normalize`  
    Dieser Filter führt eine "automatische Kontrastanpassung" des gesamten Bildes anhand einer linearen Abbildung durch.  
    Der kleinste im konkreten Bild vorkommende Wert wird auf 0 gesetzt, der größte im konkreten Bild vorkommende Wert wird auf 1 gesetzt. Die Werte dazwischen werden linear Abgebildet. Kann das Bild nicht normiert werden, weil es keinen Kontrast (nur einen konkreten sich gegebenenfalls wiederholenden Wert) hat, bleibt das Bild unverändert.

    Beispielaufruf:  

        bba --input a.pgm --input b.pgm --adiff --normalize --output -

 *  Filter `histogram`  
    Dieser Pseudo-Filter erstellt ein Histogramm. Der Filter ändert das Bild nicht, sondern gibt den Inhalt des Histogramms auf Standardausgabe aus. Das Format der Ausgabe sei eine komma-separierte Liste von Fließkommazahlen, eingeschlossen von rechteckigen Klammern. Die Anzahl von Nachkommastellen muss nicht festgelegt werden, es darf die Standardeinstellung beibehalten werden. Das Einfügen von Leerzeichen ist für bessere Lesbarkeit erlaubt.  
    Die Häufigkeiten im Histogramm seien gemäß der Bildgröße normiert. Besteht das Bild exklusiv aus Pixeln mit derselben Intensität, erreicht diese Intensität im Histogramm den Wert 1.0.  
    Es ist erlaubt, eine passende Funktion aus Open﻿CV zu verwenden.

    Beispielaufruf:

        bba --input test.pgm --histogram 2
        bba --input test.pgm --histogram 4
        bba --input test.pgm --histogram 8
        bba --input test.pgm --histogram 16
        bba --input test.pgm --histogram 256

    Der Parameter gibt die Anzahl der Klassen des Histogramms an. Die Klassen decken den gesamten Wertebereich ab und seien gleich breit.

    Beispiel eines Histogramms auf der Standardausgabe:

        [0.23, 0.27, 0.35, 0.15]

 *  Filter `sum-histogram`  
    Dieser Pseudo-Filter erstellt ein Summen-Histogramm. Der Filter ändert das Bild nicht, sondern gibt den Inhalt des Histogramms auf der Standardausgabe aus. Das Format entspreche dem des einfachen Histogramms.  
    Es ist erlaubt, eine passende Funktion aus Open﻿CV zu verwenden.

    Beispielaufrufe:

        bba --input test.pgm --sum-histogram 2
        bba --input test.pgm --sum-histogram 4
        bba --input test.pgm --sum-histogram 8
        bba --input test.pgm --sum-histogram 16
        bba --input test.pgm --sum-histogram 256

    Der Parameter gibt die Anzahl der Klassen des Histogramms an. Die Klassen seien gleich breit.

    Beispiel eines Histogramms auf der Standardausgabe:

        [0, 0.25, 0.5, 1]

    Zur einfacheren visuellen Kontrolle der Werte kann das Histogramm nach gnuplot geleitet werden. Ferner ist es erlaubt, aber nicht notwendig, die Lösung durch einen zusätzlichen Filter so zu erweitern, dass das Histogramm als Bild gezeichnet wird.

        bba --input test.pgm --sum-histogram 256 \
        | tr -d [], | sed 's/[ ]\+/\n/g' | \
        gnuplot -p -e "plot '< cat -' using 0:1 with lines notitle"

 *  Filterketten  
    Es ist nicht zu vergessen, dass mehrere Filter hintereinander angefordert werden können:

    Beispielaufruf:  

        bba --input test.pgm --brightness 0.25 --histogram 4
        
 *  Filter `histogram-check`  
    Dieser Pseudo-Filter bewertet die Qualität eines Bildes anhand seines Histogramms. Das Urteil wird als Text auf der Standardausgabe ausgegeben. Die Bildüberschriften der Beispiele stellen die vier möglichen Urteile dar.

     *  Bild ist hell.  
        <a href="http://intern.fh-wedel.de/~hoe/typolike/lena_grau_hell.pgm"><img src="http://intern.fh-wedel.de/~hoe/typolike/lena_grau_hell.png" title="Bild ist hell." style="height:4em;"></a>
     *  Bild ist dunkel.  
        <a href="http://intern.fh-wedel.de/~hoe/typolike/lena_grau_dunkel.pgm"><img src="http://intern.fh-wedel.de/~hoe/typolike/lena_grau_dunkel.png" title="Bild ist dunkel." style="height:4em;"></a>

    Ist das Bild weder zu hell noch zu dunkel, wird der Kontrast bewertet.

     *  Kontrast ist niedrig.  
        <a href="http://intern.fh-wedel.de/~hoe/typolike/lena_grau_wenigkontrast.pgm"><img src="http://intern.fh-wedel.de/~hoe/typolike/lena_grau_wenigkontrast.png" title="Kontrast ist niedrig." style="height:4em;"></a>
     *  Kontrast ist gut.  
        <a href="http://intern.fh-wedel.de/~hoe/typolike/lena_grau_std.pgm"><img src="http://intern.fh-wedel.de/~hoe/typolike/lena_grau_std.png" title="Kontrast ist gut." style="height:4em;"></a>

    Das Urteil wird genau so auf die erste Zeile der Standardausgabe geschrieben, damit ein Zeichenkettenvergleich stattfinden kann. Detailiertere Informationen dürfen auf der Standardfehlerausgabe ausgegeben werden.

    Beispielaufruf:

        bba --input lena_grau.pgm --histogram-check

 *  Das Implementieren der Filter *ist* die Aufgabe. Die äquivalenten Funktionen `cv::Mat::convertTo` und `cv::convertScaleAbs` aus Open﻿CV sollen nicht zur Implementierung der eigentlichen Funktionalität benutzt werden. Sie dürfen aber als Referenz verwendet werden. Ebenso sollen die arithmetischen Operatoren von `cv::Mat` nicht verwendet werden. `cv::calcHist` darf verwendet werden – vorausgesetzt der Teilnehmer findet heraus, wie die Funktion zu benutzen ist.

 *  Filter `leavesdetect` (optional)  
    Bestimmt den Anteil der Bildfläche, welche von Blättern eingenommen wird. Dieser Filter gibt den Bedeckungsgrad (in Prozent als Ganzzahl) auf der Standardausgabe aus.
    
    Beispielaufruf:

        bba --input blätter.jpg --leavesdetect
        
    Beispielausgabe:

        15
    
    In meinem Mietvertrag steht, dass ich das Laub im Garten harken muss, sobald der Rasen (grün) zu mehr als 50 % von Blättern (rot-gelb) verdeckt wird. Ich habe eine Webcam installiert, welche Bilder vom Boden im Garten zeigt. Wann muss ich das Laub harken?  
    <a href="https://flickr.com/photos/shogun6996/3540596199"><img src="http://intern.fh-wedel.de/~hoe/typolike/blaetter_1.jpg" title="'Grass' by Shogun_X on flickr" style="height:4em;"></a>
    <a href="https://flickr.com/photos/133462939@N07/25877311850/"><img src="http://intern.fh-wedel.de/~hoe/typolike/blaetter_2.jpg" title="'Red autumn leaf' by David G on flickr" style="height:4em;"></a>
    <a href="https://flickr.com/photos/seriousbri/6293591130"><img src="http://intern.fh-wedel.de/~hoe/typolike/blaetter_3.jpg" title="'Fallen leaves' by Brian Richardson on flickr" style="height:4em;"></a>
    <a href="https://flickr.com/photos/26098838@N08/3169349708"><img src="http://intern.fh-wedel.de/~hoe/typolike/blaetter_4.jpg" title="'Fallen Leaves' by mksfly on flickr" style="height:4em;"></a>
    <a href="https://flickr.com/photos/calliope/10235707513"><img src="http://intern.fh-wedel.de/~hoe/typolike/blaetter_5.jpg" title="'leaves' by liz west on flickr" style="height:4em;"></a>  
    (Links zeigen zu den Bildquellen. Es ist unter Umständen hilfreich, aber nicht notwendig, während der Entwicklung <a href="https://www.youtube.com/watch?v=RPg63uxYwN0" class="nomediaplugin">Fallen Leaves</a> zu hören.)
 
    Dieser Filter ist für jene gedacht, welche etwas mehr mit Open﻿CV arbeiten wollen und denen es zu langweilig ist, die Verfahren, die in der Vorlesung präsentiert worden sind, direkt zu implementieren. Dieser Filter **darf** als **Alternative** anstelle des Filter `histogram-check` implementiert werden. Wenn `leavesdetect` implementiert wird, gelten die im vorigen Punkt genannten Einschränkungen für die gesamte Aufgabe nicht. Zum Ausgleich sollen die übrigen Filter nicht nur Graustufen- sondern auch Farb-Bilder verarbeiten können.
 
##### Hinweise

 *   OpenCV arbeitet standardmäßig auf Bildern mit 8 Bit pro Kanal. Ein Graustufenbild hat exakt einen Kanel. Datentyp der cv::Mat ist `unsigned char`, der Wertebereich umfasst 265 Werte: 0 bis einschließlich 255. Die mathematischen Definitionen der oben genannten Filter sehen viel hübscher aus, wenn der Wertebereich von 0.0 bis 1.0 reicht. Es ist daher sinnvoll, mit `float` als Basisdatentyp für Intensitätswerte zu arbeiten. Hierfür soll die Methode `cv::Mat::convertTo` mit der Formatdefinition `CV_32F` verwendet werden (aber nicht zum Implementieren der Filter `linear` und co). Viele (nicht alle) Funktionen von OpenCV erkennen den Fließkommadatentyp und verhalten sich dementsprechend weiterhin korrekt.
 
 *  Das "Pseudo-" in "Pseudo-Filter" zeigt an, dass der Filter bei seiner Arbeit das Bild nicht verändert. Auch der Bilderstapel wird nicht manipuliert.

 *  Der Filter `adiff` in Kombination mit einem Histogramm von 256 Klassen, dessen erste Klasse gegen 1.0 geprüft wird, kann für automatisierte Tests der übrigen Funktionen genutzt werden.

 *  Filter, welche pixel-weise auf zwei Bildern arbeiten, benötigen zwei Bilder mit gleichen Abmessungen. Dies darf erwartet werden, eine Überprüfung muss nicht stattfinden.

 *  Zum Testen ist es oftmals nützlich, mit kleinen Bildern zu arbeiten, deren Pixelintensitäten manuell überprüft werden können.

 *  Die Filter sind vorzugsweise so zu implementieren, dass man sie auch innerhalb dieser Lösung wiederverwenden kann, um redundante Implementierungen zu vermeiden.

 *  Diese Aufgabenstellung wurde von Erik Jenning maßgeblich verbessert.

#### Gruppenzuordnung bei Abnahme

Rotation der Verteilung von voriger Abnahme.

Zeitslots:

1. 11:00
1. 11:25
1. 11:50
1. 12:30
1. 12:55
1. 13:20

**Hermann "hoe" Höhne** – 🐧 (⊞)
