### Funktoren

Seit C++11 werden Aspekte der funktionalen Programmierung durch verschiedene Konzepte unterstützt, unter anderem sogenannte "Funktoren". In anderen Programmiersprachen sind sie auch als Closures bekannt. In C++ werden sie mit Hilfe anonymer "Lambda" Funktionen definiert und können als Funktionsobjekte gehandhabt werden.

#### Beispiel

    /**
     * @file funktoren.cpp
     * 
     * Beispiel für die Deklaration eines Funktionstypen und 
     * die Definition eines Funktors durch einen Lambda-Ausdruck.
     */

    #include <iostream> // für std::cout
    #include <functional> // für std::function

    /**
     * Addiert 1.
     */
    int increment(int i) {
        return i+1;
    }

    /**
     * Einstiegspunkt, zur Demonstration der Verwendung eines Funktors.
     */
    int main(int argc, char *argv[])
    {
        // definiert den Typ des Funktors für den Bezeichner "operation":
        std::function<int(int)> operation;
        operation = increment; // setzt die auszuführende Operation

        int zahl = 0;
        zahl = operation(zahl); // führt die Operation aus
        std::cout << zahl << std::endl; // gibt 1 aus
        
        operation = // "operation" mit Lambda-Ausdruck belegt:
            [] (int i) -> int // beim Aufruf wird ein int "i" erwartet und ein int zurückgegeben
            {return i*2;} // Funktionsrumpf
            ; // Ende der Zuweisung auf Bezeichner "operation"
        zahl = operation(zahl);
        zahl = operation(zahl);
        zahl = operation(zahl);
        std::cout << zahl << std::endl; // gibt 8 aus
    }

#### Erklärung

In "Programmstrukturen 2" werden in Java Klassen definiert. Ein Lambda-Ausdruck hat eine gewisse Ähnlichkeit mit einer Klasse, welche ad hoc deklariert wird und nicht erben kann. Genau ein Objekt dieser Klasse wird erzeugt.  
In der C++ Lambda Syntax beschreiben die rechteckigen Klammern die "Capture Group". Die hier stehenden Bezeichner werden zur Definitionszeit "eingefangen". Innerhalb des Funktionsrumpfs kann auf sie zugegriffen werden. Implizit werden dabei konstante Kopien der Werte angelegt. Auch das Referenzieren und sogar das Verschieben des Bezeichners in den Gültigkeitsbereich der anonymen Funktion ist möglich.

Java-Beispiel für einen flexiblen Inkrementierer mit Hilfe einer inneren Klasse:

    public static void main(String[] args) {
    
        class Inkrementer {
            private final int inkrement;
            Inkrementer(int inkrement) {
                this.inkrement = inkrement;
            }
            int inkrementiere(int i) {
                return i+inkrement;
            }
        }
        Inkrementer inkrementer = new Inkrementer(37);
        
        int i = 5;
        System.out.println(inkrementer.inkrementiere(5));
    }

Ein funktionsgleiches Beispiel in C++:

    int main(int argc, char *argv[]) {
        
        int inkrement = 37;
        std::function<int(int)> inkrementer = [inkrement] (int i)->int {
            return inkrement+i;
        };
        
        int i = 5;
        std::cout << inkrementer(5) << std::endl;
    }

Die Lambda-Schreibweise ist deutlich kompakter. Die Parameter, welche dem Konstruktor übergeben werden, finden sich in der Capture Group wieder. Die Signatur kann deswegen kompatibel bleiben, obwohl eine anonyme Funktion zur Arbeit mehr Parameter (mit konstanten Werten) benötigt, als beim Aufruf angegeben sind. Dadurch ist viel Flexibilität möglich, ohne den planerischen Mehraufwand von Klassenhierarchien zu haben.


Weiterführender Hinweis: Auch in Java gibt es anonyme Funktionen. Besonders populär sind sie auch in ECMAScript, insbesondere im Zusammenspiel mit Promises. Das Konzept der anonymen Funktionen ist also kein rein theoretisches Spielzeug, welches nur in diesem Praktikum vorkommt.
Weiteres Material gibt es unter Anderem hier:

* https://blog.feabhas.com/2014/03/demystifying-c-lambdas/
* https://medium.com/@winwardo/c-lambdas-arent-magic-part-1-b56df2d92ad2