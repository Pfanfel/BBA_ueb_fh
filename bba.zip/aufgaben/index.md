# Praktikum Bildbearbeitung und Bildanalyse

**ACHTUNG:** Als Vorbedingung muss die *Übung* "Systemnahe Programmierung" (in C) bestanden worden sein.

## Leiter und Abnehmer:

* [Hermann "hoe" Höhne](http://www.fh-wedel.de/mitarbeiter/hoe/) in M14
* Stefan Nitz
* Julian Weihe
* Babak Nouri

## Zeit und Ort:

Vorstellung: Dienstag, 15:30, RZ2  
Fragestunde: Dienstag, 15:30 bis 18:15, RZ2  
Abnahme: Dienstag, 15:30 bis 18:15, RZ2  
Termine siehe unten.

## Termine:

**ACHTUNG: Die erste Aufgabenvorstellung findet wirklich VOR der ersten Vorlesung statt.**

| KW | VL# | VL-Titel                     | Termin (Vorl.) | Termin (Praktikum) | Praktikum |
|--|--|--|--|--|--|--|
| 15 |  1 | Einführung, Farbräume         | Do, 12. April  | Di, 10. April | Vorstellung Aufgabe 0 (in RZ2) |
| 16 |  2 | Dateiformate, Digitalisierung | Do, 19. April  | Di, 17. April | Fragestunde           |
| 17 |  3 | Histogrammtransformationen    | Do, 26. April  | Di, 24. April | Abnahme Aufgabe 0     |
| 18 |  4 | Compositing                   | Do, 03. Mai    | Di, 01. Mai   | (Feiertag)            |
| 19 |    | (Feiertag)                    | Do, 10. Mai    | Di, 08. Mai   | Vorstellung Aufgabe 1 |
| 20 |  5 | lineare lokale Filter         | Do, 17. Mai    | Di, 15. Mai   | Fragestunde           |
| 21 |  6 | Morphologische Filter         | Do, 24. Mai    | Di, 22. Mai   | Abnahme Aufgabe 1     |
| 22 |    | (Verfügungstag)               | Do, 31. Mai    | Di, 29. Mai   | Vorstellung Aufgabe 2 |
| 23 |  7 | ?                             | Do, 07. Juni   | Di, 05. Juni  | Fragestunde (Verfügungstag) |
| 24 |  8 | Geometrische Transformation   | Do, 14. Juni   | Di, 12. Juni  | Abnahme Aufgabe 2     |
| 25 |  9 | Frequenzfilter                | Do, 21. Juni   | Di, 19. Juni  | Vorstellung Aufgabe 3 |
| 26 | 10 | Segmentierung                 | Do, 28. Juni   | Di, 26. Juni  | Fragestunde           |
| 27 | 11 | Registrierung                 | Do, 05. Juli   | Di, 03. Juli  | Abnahme Aufgabe 3     |
| 28 | 12 | Neuronale Netze               | Do, 12. Juli   | Di, 10. Juli  | Vorstellung Aufgabe 4 |

Diese Terminverteilung stellt sicher, dass die zum Lösen der Aufgabe notwendigen Inhalte in der Vorlesung zum Zeitpunkt der Aufgabenvorstellung behandelt worden sind. Jede Aufgabe ist bis zum Termin der Abnahme zu lösen. Die Abgabe der vierten Aufgabe erfolgt außerhalb der Vorlesungszeit an einem mit dem Abnehmer persönlich bis zum **13.** **Juli** **2018** vereinbarten Abnahmetermin. Die Abnahme muss spätestens am **7.** **September** **2018** stattfinden.

## Newsgroup:

[fhw.bba](news://news.fh-wedel.de/fhw.bba)

## Zugehörige Vorlesung:

Bildbearbeitung und -analyse gelesen von 
[Prof. Dr. Dennis Säring](http://www.fh-wedel.de/mitarbeiter/dsg/).

## Lernziele:

Das Praktikum Bildbearbeitung und Bildanalyse vertieft und festigt die in der Vorlesung präsentierten Verfahren. Im Vordergrund steht das Sammeln von praktischen Erfahrungen bei der Implementierung bildorientierter Algorithmen. Der Umgang mit der Programmiersprache C++ wird geübt als Vorbereitung zur Arbeit mit hoch optimierten industriell genutzen Bibliotheken.
