Diese Aufgabe dreht sich um geometrische Bildtransformation.

Beim Bearbeiten dieser Aufgabe ist zu beachten, dass die Rahmenbedingungen zu Richtlinien und Bewertung für alle Aufgaben gelten.

<nolink>
#### Aufgabenstellung

Basisteil:

 *  automatische Zielbildgrößenbestimmung
 *  Rotation

Bewertungsteil:

 *  Skalieren (1 Punkt)
 *  Scheren (1 Punkt)
 *  beliebige Matrix (1 Punkt)
 *  Aufrichten (2 Punkte)
 *  Verkettung (2 Punkte)
 *  Interpolationsmethode: bilinear (2 Punkte)

##### Details

In dieser Aufgabe sollen die affinen Transformationen mit Interpolation bei inverser Abbildung implementiert werden.
In OpenCV sind Datenstrukturen für Punkte und Matrizen bereits vorgegeben. Auch die Matrixmultiplikation und das Invertieren einer Matrix ist in OpenCV implementiert. Diese Funktionen bzw. Operatoren von OpenCV sollen verwendet werden.  
Das Implementieren der eigentlichen Transformation ist Teil dieser Aufgabe. Konsequenterweise dürfen `cv::warpAffine`, `cv::flip`, `cv::rotate`, `cv::resize`, `cv::transpose`, `cv::transform` und ihre Alternativen zur Lösung der Aufgabe nicht verwendet werden.  
Das bedeutet, dass Punkte und Matrizen manuell erzeugt und in homogene Form überführt werden müssen. Als Datentyp für die homogene Matrix bietet sich eine der streng typisierten Varianten von `cv::Matx` an.

 *  Die Größe des Zielbildes ist unmittelbar vor dem Durchführen der inversen Abbildung zur geometrischen Bildtransformation zu berechnen. Das transformierte Eingabebild sei in der Ausgabe vollständig und zentriert eingepasst zu sehen. Die Randbehandlung aus Aufgabe 2 muss bestehen bleiben.

 *  Filter `rotate`  
    Der Parameter gebe die Drehung in Grad im mathematisch negativen Drehsinn (umgangssprachlich "im Uhrzeigersinn") an.  
    Rotationen um (Vielfache von) 90 Grad müssen **exakt** (verlustfrei) sein.

    Beispielaufrufe:

        bba --input test.pgm --rotate    0 --output -
        bba --input test.pgm --rotate  -90 --output -
        bba --input test.pgm --rotate  180 --output -
        bba --input test.pgm --rotate  -10 --output -
        bba --input test.pgm --rotate   45 --output -
        bba --input test.pgm --rotate 0.25 --output -

 *  Filter `scale`  
    Die Parameter geben die Skalierung in x- und y-Richtung an.  
    Skalierungen um Ganzzahlige positive Werte sollen exakt sein. Bei einer Skalierung um 2x2 wird jeder Pixel durch die Wahl des nächsten Nachbarn auf genau vier Pixel abgebildet.

    Beispielaufrufe:

        bba --input test.pgm --scale 1.0 1.0 --output - # nichts passiert
        bba --input test.pgm --scale 2.0 2.0 --output - # vierfache Größe
        bba --input test.pgm --scale 2.0 1.0 --output - # doppelte Breite
        bba --input test.pgm --scale 1.0 0.5 --output - # halbe Höhe
        bba --input test.pgm --scale  -1  -1 --output - # Punktspiegelung

 *  Filter `shear`  
    Der Parameter gibt den Scherfaktor an.

    Beispielaufrufe:

        bba --input test.pgm --shear 0.0 --output - # nichts passiert
        bba --input test.pgm --shear 1.0 --output -

 *  Filter `transform`  
    Die Parameter repräsentieren die Elemente der Abbildungsmatrix.

    Beispielaufrufe:

        bba --input test.pgm --transform 1 0 0 1 --output - # nichts passiert
        bba --input test.pgm --transform 2 0 0 1 --output - # doppelte Breite
        bba --input test.pgm --transform 1 2 3 4 --output -
    
    Der letzte Aufruf führt intern zu dieser homogenen Abbildungsmatrix:

            1  2  0
            3  4  0
            0  0  1

 *  Filter `upright`  
    Berechnet mit Hilfe der Passpunktmethode eine Transformationsmatrix, welche einen angegebenen Bildbereich wieder Rechteckig abbildet. Der Filter nimmt als Parameter die Zielgröße sowie drei Koordinaten der Punkte links unten, links oben und rechts oben: `Breite Höhe x₁ y₁ x₂ y₂ x₃ y₃` Da der Benutzer die Koordinaten angibt, kann es sein, dass Bildteile abgeschnitten werden oder zusätzlicher Rand entsteht. Der vom Benutzer ausgewählte Ausschnitt soll in das Ergebnisbild eingepasst sein.

    Beispielaufrufe:

        bba --input test_256x256.pgm --upright 256 256  0 255  0 0  255 0 --output - # nichts passiert
        bba --input test.pgm --upright 360 512  66 430  292 48  672 317 --output -

    Für das Lösen des Gleichungssystems bietet sich eine Funktion in OpenCV an. Sie darf gesucht, gefunden und verwendet werden.

 *  Verkettung  
    Stehen mehrere affine Abbildungen (`rotate`, `scale`, `shear`, `transform`) hintereinander an, sollen ihre Abbildungsmatritzen kombiniert werden, sodass die eigentliche Arbeit auf dem Bild nur einmal stattfinden muss. `upright` darf, muss aber nicht in diesem Kontext beachtet werden. Diese Aufrufe sind äquivalent und liefern das gleiche Ergebnisbild: 

        bba --input test.pgm --scale 0.5 0.5 --scale 2.0 2.0 --rotate 45 --rotate -45 --output -
        bba --input test.pgm --scale 2.0 2.0 --rotate 45 --scale 0.5 0.5 --rotate -45 --output -
        bba --input test.pgm --rotate 45 --scale 2.0 2.0 --scale 0.5 0.5 --rotate -45 --output -

 *  Interpolationsmethoden  
    Hierfür wird ein neuer Parameter `--interpolation` zur Auswahl der Interpolationsmethode definiert. Die Auswahl wirkt global für alle Filter mit inverser Abbildung.

     *  Nächster Nachbar: `nearest`  
        Dies ist die Standardeinstellung, wenn keine Interpolationsmethode explizit angegeben wurde. Beim Implementieren der inversen Abbildung entsteht durch intuitive Programmierung im Normalfall automatisch eine Interpolation fehlender Bildpunkte durch Auswahl des nächsten Nachbarn.  
        <img src="http://intern.fh-wedel.de/~hoe/typolike/lena_rotate-45nn.png" alt="Lena um 45° gedreht, mit nächstem Nachbar als Interpolation."/>
     *  Bilinear: `bilinear`  
        Bilineare Interpolation.  
        <img src="http://intern.fh-wedel.de/~hoe/typolike/lena_rotate-45bili.png" alt="Lena um 45° gedreht, mit bilinearer Interpolation."/>

    Beispielaufruf:

        # Vierfache Größe mit Nächstem Nachbarn als Interpolation
        bba --input test.pgm --scale 2 2 --output - # hat den gleichen Effekt wie der nächste Aufruf
        bba --input test.pgm --interpolation nearest --scale 2 2 --output -

        # Doppelte Höhe mit bilinearer Interpolation
        bba --input test.pgm --interpolation bilinear --scale 1 2 --output -

 *  Randbehandlung
     
    Die Randbehaldlung aus dem Basisteil von Aufgabe 2 hat auch in Aufgabe 3 bestand.
     
        bba --input test.pgm --edge replicate --interpolation bilinear --rotate 45 --output -

    <img src="https://lms.rechnernetze.fh-wedel.de:888/pluginfile.php/11429/mod_assign/introattachment/0/lena_replicate.png?preview=thumb">

##### Hinweise

Es gibt ein neues Makefile und neue CMakeLists. Diese verwenden andere Einstellungen, sodass g++ und MSVC mehr Warnungen ausgeben bei Code, der den Richtlinien widerspricht.

Es ist erlaubt, dass die als `Operation` bekannte Struktur nur einen `std::string`, einen `std::vector<float>` und gegebenenfalls Aufzählungstypen beinhaltet. Es ist ebenso erlaubt, aber nicht notwendig, jeden denkbaren Wert mit einem eigenen Bezeichner in der Struktur unterbringen zu wollen.

Damit Operationen einfach konkateniert werden können, ist es erlaubt und sinnvoll, jede der Operationen zur geometrischen Transformation in zwei Funktionen aufzuteilen, z.B. `make_affine_matrix_rotate(float degrees)` und `affine_transform(cv::Mat & image, cv::Mat matrix)`. Auf diese Weise können die Matrizen aufeinander folgender Transformationen im Hauptprogramm kombiniert werden.

Bei einer naiven Implementierung werden gerne die Indizes der Pixel direkt als die Position wahrgenommen. Das ist nicht ganz korrekt und führt in eine Welt voller Schmerzen. Eine Erläuterung ist in [diesem Video](https://stud.fh-wedel.de/handout/H%C3%B6hne_Hermann/Beispiel%20Digitale%20Vorlesung/Aufgabe3_Hinweis_Indizes-vs-Position.mp4) gegeben.

Wer überall exakt arbeiten will, findet bei dieser Aufgabe hohes Potential für Frustration. Wird nicht zufällig eine glückliche Implementierung gewählt, kann es bezüglich der Abmessungen des Zielbildes und der Position des transformierten Quellbildes auf der Fläche des Zielbildes zu ±1 Fehlern kommen. Dies wird bei der Abnahme toleriert. Nur die Rotationen um 90 Grad werden automatisch kontrolliert und müssen perfekt sein. Abstürzen (weil z.B. Pixel außerhalb des Bildes geschrieben werden) darf das Programm dennoch nicht. Innerhalb des transformierten Bildes sollen nie Probleme sichtbar sein.

Diese Fehler dürfen nicht sichtbar sein:

 *  Zielbildgröße stimmt nicht:  
    <img src="http://intern.fh-wedel.de/~hoe/typolike/lena_rotate_groessenfehler.png" />
 *  Positionierung im Zielbild stimmt nicht:  
    <img src="http://intern.fh-wedel.de/~hoe/typolike/lena_rotate_positionsfehler.png" />
 *  Bildfehler innerhalb des Bildes:  
    <img src="http://intern.fh-wedel.de/~hoe/typolike/lena_rotate_innererfehler.png" />

Solche Abweichungen sind akzeptabel, sofern sie nicht systematisch immer vorkommen:

 *  1 Pixel zusätzlicher Rand:  
    <img src="http://intern.fh-wedel.de/~hoe/typolike/lena_rotate_vielrand.png" />
 *  1 Pixel Versatz:  
    <img src="http://intern.fh-wedel.de/~hoe/typolike/lena_rotate_versatz.png" />

</nolink>
#### Gruppenzuordnung bei Abnahme:

Rotation der Verteilung von voriger Abnahme.  
Bei Bedarf dürfen Tauschvorschläge individuell mit dem Abnehmer koordiniert werden.

Zeitslots:

1. 11:00
1. 11:25
1. 11:50
1. 12:30
1. 12:55
1. 13:20

**Hermann "hoe" Höhne** – 🐧 (⊞)
