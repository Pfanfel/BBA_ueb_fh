Für die nächsten Beispiele wird davon ausgegangen, dass das Programm den Namen `bba` trägt. Ein "Befehl" besteht aus einem identifizierenden "Verb" und optional einer bekannten Anzahl an Optionen. `--input` und `--output` sollen unabhängig von der Aufgabenstellung in jeder Lösung vorhanden sein. Die Filter werden für jede Aufgabe separat definiert. Alte Filter dürfen gerne auch in späteren Lösungen funktionsfähig vorhanden sein. Die hier angegebenen Beispiele stellen gültige Eingaben dar.

 *  `--input <Dateiname>`  
    Dateiname des Eingabebildes.

        bba --input eingabe.pgm
    
    Das Einlesen des Bildes übernimmt `cv::imread`.  
    Zu bedenken ist, dass auch ein Farbbild ausschließlich aus Grautönen bestehen kann. Als Eingabe sind jedoch zunächst nur Graustufen-Bilder zu erwarten. Diese können tatsächlich nur Grautöne darstellen und keine Farben. Bei JPEG Bildern ist hierfür ein spezieller Modus zu aktivieren. Das ASCII Bildformat "Portable Graymap" ist für Testzwecke hilfreich, da sich die Intensitätswerte direkt ablesen lassen. Beim Lesen von Portable Anymap Dateien werden die Intensitätswerte automatisch auf den üblichen Wertebereich (0 bis 255 im Falle von Pixeln mit 8 Bit Wortbreite) gestreckt. Dies ist in Ordnung und muss nicht manuell "korrigiert" werden.  

 *  `--output <Dateiname>`  
    Kontrolle über die Ausgabe.
 
     *  Ist der Dateiname `"-"`, soll das Ergebnisbild auf die Standardausgabe geschrieben werden.
        Auf der Standardausgabe soll das Bild als [Portable Anymap](https://de.wikipedia.org/wiki/Portable_Anymap) ausgegeben werden. Portable Anymap ist der Oberbegriff für eine Reihe von Unterformaten. Für uns sind auf der Standardausgabe nur die ASCII Varianten relevant. Konkret sollen Graustufenbilder als Portable Graymap und Farbbilder als Portable Pixmap ausgegeben werden.  
        Der Standard schreibt es nicht vor, aber jede Bildzeile soll einer Ausgabezeile entsprechen. Der Header soll auf drei Zeilen verteilt werden.  
        Die beim Lesen geschehene Anpassung des Wertebereiches auf 0 bis 255 muss nicht rückgängig gemacht werden.
     *  In den übrigen Fällen wird das Bild in den angegebenen Dateinamen geschrieben. Das Schreiben des Bildes in eine Datei übernimmt `cv::imwrite`.
     
     Beispiele für gültige Aufrufe:

            bba --input eingabe.jpg # es wird keine Ausgabe gemacht
            bba --input eingabe.png --output - | display - # display zeigt das Bild unverändert an
            bba --input eingabe.pgm --output ausgabe.png # speichert das Bild unverändert ab
            bba --input eingabe.tif --brightness +0.1 --output - | display - # display zeigt das aufgehellte Bild an
            bba --input eingabe.bmp --histogram 256 # gibt das Histogramm aus, aber nicht das Bild

    `display` ist ein Programm aus der ImageMagick Sammlung.

 *  `--<Filtername> <Optionen>`  
    Wählt einen anzuwendenden Filter. Dieser Parameter kann beliebig oft genannt werden. Fehlt er, wird das Bild unverändert ausgegeben. Die Filter sollen in der genannten Reihenfolge auf das Bild angewendet werden. Der Filtername ist ein String, die Filter-Optionen sind vom Typ `float`. Die Anzahl der Filter-Optionen ist vom jeweiligen Filter abhängig.
    
        bba --input eingabe.png --brightness 0.5
        bba --input eingabe.png --window 300 600 --erode
        bba --input eingabe.png --input eingabe.png --addition
        
    Die Filter arbeiten auf den Pixelwerten der Bilder. Ihre Implementierung gehört zu den Aufgaben dieses Praktikums.

 *  Globale Parameter
    Einige Programmparameter setzen Einstellungen, welche sich auf alle nachfolgenden Filter auswirken. Diese Parameter werden in der Form  
    `--<parametername> <parameterwert>`  
    erwartet.
    
        bba --input eingabe.png --interpolation bilinear --scale 2.0 2.0
        
    Ein solcher Parameter wirkt sich auf die nachfolgenden Filter aus. Bei mehrfacher Nennung desselben Parameters gewinnt die letzte Nennung. Obwohl der Parameter globale Auswirkungen zu haben scheint, soll die Variable, in welcher die Einstellung gespeichert ist, nicht global sein, sondern im Hauptprogramm liegen.

 *  Reihenfolge
 
    Die Reihenfolge der Filter ist bei der Ausführung signifikant.

        bba --input eingabe.pgm --brightness +0.1 --output ausgabe.pgm # ein Bild wird aufgehellt abgespeichert
        bba --brightness +0.1 --input eingabe.pgm --output ausgabe.pgm # FEHLER: Filter kann ohne Bild nicht arbeiten
        bba --output ausgabe.pgm --input eingabe.pgm --brightness +0.1 # FEHLER: Ausgabe kann ohne Bild nicht erfolgen
        bba --input eingabe.pgm --gamma 2.0 --brightness +0.1 --output ausgabe.pgm # erst Gammakorrektur, dann Aufhellung
        bba --input eingabe.pgm --brightness +0.1 --gamma 2.0 --output ausgabe.pgm # erst Aufhellung, dann Gammakorrektur
        bba --interpolation bilinear --input eingabe.pgm --scale 2.0 2.0 --output ausgabe.pgm # Skalierung mit bilinearer Interpolation
        bba --input eingabe.png --addition --input eingabe.png # FEHLER: Filter braucht zwei Bilder
        
    Die Fehler müssen nicht abgefangen werden. Bei fehlerhaften Programmaufrufen darf das Programmverhalten undefiniert sein.

Diese Beispiele decken alle Typen von Parametern ab.
