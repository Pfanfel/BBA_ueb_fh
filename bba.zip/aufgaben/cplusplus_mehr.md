Du willst mehr C﻿++? Du bekommst mehr C﻿++!

### Konstante Referenzen

Man kann Referenzen auch als konstant Deklarieren die Werte sind immer noch effizient zugreifbar, können aber nicht geändert werden. Das Verwenden von konstanten Referenzen gibt dem Übersetzer mehr Möglichkeiten, die Ausführungsgeschwindigkeit zu verbessern.

#### Beispiel

    /**
     * @file referencevspointerdemo.cpp
     * @brief Beispielprogramm zur Demonstration von konstanten Referenzen.
     */

    #include <iostream> // für std::cout

    /**
     * Funktion zur Demonstration einer konstanten Referenz.
     * Die Daten des Parameters werden nicht kopiert und sind schreibgeschützt.
     */
    void ausgeben(const int & i) {
        // das Ändern des Wertes von i ist hier nicht möglich
        // der Versuch führt zu einem Fehler während des Übersetzens
        // das Lesen funktioniert aber
        std::cout << i << std::endl;
    }
    
    /**
     * Einstiegspunkt zur Demonstration von konstanten Referenzen.
     */
    int main(int argc, char *argv[]) {
        int zahl = 3;
        ausgeben(zahl); // hier wird 3 ausgegeben
    }

Parameter, welche als konstante Referenz übergeben werden, haben große Vorteile. Der Compiler hat hier sehr gute Möglichkeiten zur Optimierung. Insbesondere Standard-Behälter, deren Daten normalerweise durch Kopieren übertragen werden, können so viel effizienter an Unterfunktionen übergeben werden. Auch Objekte können als konstante Referenz übergeben werden, sofern in der Unterfunktion keine Mutatoren dieses Objektes aufgerufen werden. Der Compiler überprüft auch das automatisch.  
Hinweis: Bei der Rückgabe von Werten mittels `return` wird ohnehin selten kopiert, weil moderne Compiler fähig sind zur [Copy Elision](https://en.wikipedia.org/wiki/Copy_elision).  

### Funktoren mit Referenzen

Besonders mächtig sind Referenzen in Kombination mit Funktoren.

#### Beispiel

    /**
     * @file funktoren.cpp
     * 
     * Beispiel für die Deklaration eines Funktionstypen und 
     * die Definition eines Funktors durch einen Lambda-Ausdruck.
     */

    #include <iostream> // für std::cout
    #include <functional> // für std::function

    /**
     * Einstiegspunkt, zur Demonstration der Verwendung eines Funktors.
     */
    int main(int argc, char *argv[])
    {
        int zahl = 2;
        int total = 0;
        std::function<void(int&)> operation = // "operation" mit Lambda-Ausdruck belegt:
            [&total] // variable "total" wird als Referenz eingefangen
            (int&i) // beim Aufruf wird ein int als Referenz erwartet
            mutable // dieser Funktor mutiert (ohne dies ist die o.g. Referenz const)
            {total += i;} // Funktionsrumpf
            ; // Ende der Zuweisung auf Bezeichner "operation"
        operation(1);
        operation(zahl);
        operation(zahl);
        std::cout << total << std::endl; // gibt 5 aus
    }

### Automatisches Bestimmen des Datentyps

Es kommt vor, dass das Formulieren des Datentyps anstrengend ist. Bei sehr lokaler Verwendung einer Variable bietet sich das Verwenden der automatischen Bestimmung mittels `auto` an. Gravierender Nachteil: Der Compiler hat möglicherweise einen anderen (zur deklarationszeit kompatbilen) Typ ermittelt als der Rest der Implementierung erwartet.

#### Beispiel

    /**
     * Beispiel für die Verwendung von auto
     */
    int main(int argc, char *argv[]) {
        auto funktion = [](int x) {return x++};
        
        for (int i = 0; i < 5 ; i++) {
            std::cout << funktion();
        }
        std::cout << std::endl;
    }

### Bereichsbasierte Schleifen

Bereichsbasierte Schleifen sind das foreach in C﻿++.

#### Beispiel

    #include <iostream> // für std::cout
    #include <vector> // für std::vector

    /**
     * Einstiegspunkt zur Demonstration von bereichsbasierten Schleifen.
     */
    int main(int argc, char *argv[]) {
        std::vector<int> zahlen = {0,1,2,3};
        
        // traditionelle Schleife
        // Zugriff über Index
        for (int i = 0; i < zahlen.size() ; i++) {
            std::cout << zahlen[i]++;
        } // gibt aus 0123 und manipuliert die Daten im Vektor
        std::cout << std::endl;
        
        // bereichsbasierte Schleife ohne Referenz
        // jedes Element wird einmal in den Bezeichner "zahl" kopiert
        for (int zahl : zahlen) {
            std::cout << zahl--;
        } // gibt aus 1234, manipuliert aber nur lokale Kopie
        std::cout << std::endl;
        
        // bereichsbasierte Schleife mit Referenz
        // beim Iterieren werden keine Daten kopiert
        for (int & zahl : zahlen) {
            std::cout << zahl--;
        } // gibt aus 1234 und manipuliert die Daten im Vektor
        std::cout << std::endl;
        
        // bereichsbasierte Schleife mit konstanter Referenz
        // Daten sind schnell verfügbar und schreibgeschützt
        for (const int & zahl : zahlen) {
            // zahl++ ist hier nicht möglich
            std::cout << zahl;
        } // gibt aus 0123
        std::cout << std::endl;
    }

Intern verwenden bereichsbasierte Schleifen Iteratoren.

### Iteratoren

Iteratoren bieten eine weitere Möglichkeit zum Iterieren über die Elemente einer Sammlung.

### Smart Pointers

Wer in C﻿++ unbedingt Zeiger benutzen will oder muss, der kann *smart pointers* verwenden. Mit nur ein bisschen mehr Schreibarbeit bleibt so die automatische Speicherverwaltung intakt und komfortabel. Beispiele für Situationen, in welchen Zeiger notwendig sind:

* Objekte verschiedener Klassen (mit einer gemeinsamen Elternklasse) sollen in einer Datenstruktur verwaltet werden, aber object-slicing muss vermieden werden.
* Daten müssen zwingend auf dem Heap liegen, nicht auf dem Stack

Ein Beispielprogramm mit `shared_ptr`:

    #include <memory>
    #include <iostream>

    class Verbose {
      private:
      int i;
      public:
      Verbose(int i):i(i) {
        std::cerr << "Constructor " << this << std::endl;
      }
      ~Verbose() {
        std::cerr << "Destructor  " << this << std::endl;
      }
    };

    int main(int argc, char** argv) {
      {
        // traditionelles Anlegen eines Objektes auf dem Heap
        Verbose *v = new Verbose(0);
        // delete vergessen – Speicherleck
      }
      {
        // sobald er stirbt, zerstört der shared_ptr das ihm gegebene Objekt automatisch
        std::shared_ptr<Verbose> v = std::make_shared<Verbose>(1);
      }
    }

`shared_ptr` können kopiert werden. Soll sichergestellt werden, dass Zugriff auf das verwaltete Objekt nur von einem Gültigkeitsbereich aus möglich ist, gibt es alternativ den `uniqe_ptr`.

### Templates

C﻿++ unterstützt Templates. Solche sind mit Java Generics vergleichbar. Wer solche Funktionen mit Vorlagen verwendet, kann oft Redundanz vermeiden. Das Erdenken eigener vorlagenbehafteter Funktionen ist im Rahmen dieses Praktikums jedoch nicht notwendig.

#### Beispiel

    /**
     * @file templatedemo.cpp
     * @brief Beispielprogramm zur Demonstration von vorlagenbehafteten Funktionen.
     */

    /**
     * Diese Funktion inkrementiert eine Zahl eines beliebigen angegebenen Typs.
     * Die Template-Definition reserviert den Bezeichner T für einen anzugebenden Typ.
     * @param Zahl die zu inkrementierende Zahl. Beachte die Typangabe mittels T.
     * @return Die inkrementierte Zahl. Der Typ wird in der Funktionssignatur festgelegt.
     */
    template <typename T>
    T inkrementiere(T zahl) {
        return zahl+1;
    }

    /**
     * Einstiegspunkt, welcher die vorlagenbehaftete Funktion aufruft.
     */
    int main(int argc, char *argv[]) {
        int a = 0;
        inkrementiere<int>(a); // beachte die Typangabe *hinter* dem Funktionsnamen.
    }
    
Wegen Eigenheiten der Abläufe beim Übersetzen von C﻿++ müssen vorlagenbehaftete Funktionen im Header definiert werden. Eine klassische Aufteilung mit der Deklaration im .hpp Header und der Definition in der .cpp Datei ist nicht möglich.